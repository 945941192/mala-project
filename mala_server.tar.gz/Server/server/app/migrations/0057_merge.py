# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('app', '0056_auto_20160130_1812'),
        ('app', '0052_add_other_region2'),
    ]

    operations = [
    ]
