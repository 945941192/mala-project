# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('app', '0030_add_timeslots'),
        ('app', '0030_auto_20160111_1127'),
    ]

    operations = [
    ]
