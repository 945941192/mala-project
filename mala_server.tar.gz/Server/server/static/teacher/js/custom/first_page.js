$(
    function(){
        $("#close-complete-table-bar").click(function(){
            $("#complete-table-bar").attr("attrHidden", "true");
        });
    }
);
