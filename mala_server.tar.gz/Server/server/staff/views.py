import logging
import datetime
import json
import re
from collections import OrderedDict
import xlwt

# django modules
from django.conf import settings
from django.core.files.base import ContentFile
from django.shortcuts import render, redirect, get_object_or_404
from django.http import HttpResponse, JsonResponse
from django.views.decorators.http import require_POST
from django.views.generic import View, TemplateView, ListView
from django.utils.decorators import method_decorator
from django.contrib import auth
from django.db import IntegrityError, transaction
from django.db.models import Q, Sum, Max, Min
from django.utils import timezone
from rest_framework.renderers import JSONRenderer
from django.contrib.auth.mixins import AccessMixin

# local modules
from app import models
from app.utils import smsUtil
from app.utils.algorithm import check_id_number
from app.utils.types import parseInt, parse_date, parse_date_next
from app.utils.db import paginate, Pager
from app.utils import excel
from .decorators import mala_staff_required, is_manager
from app.exception import TimeSlotConflict, OrderStatusIncorrect, RefundError
from app.tasks import send_push, Remind, send_sms


logger = logging.getLogger('app')

# Create your views here.


@mala_staff_required
def index(request):
    return render(request, 'staff/index.html')


def login(request, context=None):
    if context is None:
        context = {}
    if is_manager(request.user):
        return redirect('staff:index')
    return render(request, 'staff/login.html', context)


def logout(request):
    auth.logout(request)
    return redirect('staff:login')


@require_POST
def login_auth(request):
    username = request.POST.get('username')
    password = request.POST.get('password')
    goto_page = request.POST.get('next')
    logger.debug('try to login, username: '+username+', password: '+password+', goto_page: '+str(goto_page))
    # TODO: 错误信息包含‘错误码’，错误描述可能会变
    if not username or not password:
        return login(request, {'errors': '请输入用户名和密码'})
    # 登录前需要先验证
    newUser=auth.authenticate(username=username,password=password)
    if newUser is not None:
        if not is_manager(newUser):
            return login(request, {'errors': '你不是管理员呀'})
        auth.login(request, newUser)
        if goto_page:
            return redirect(goto_page)
        else:
            return redirect('staff:index')
    return login(request, {'errors': '用户名或密码错误'})


def _try_send_sms(phone, tpl_id=0, params=None, times=1):
    """
    尝试发送短信
    :return: True or False
    """
    if params is None:
        params = {}
    if not phone:
        return False
    if not tpl_id:
        return True
    if settings.FAKE_SMS_SERVER:
        return True
    try:
        smsUtil.tpl_send_sms(phone, tpl_id, params)
    except Exception as ex:
        send_sms.apply_async((phone, tpl_id, params, times), countdown=32) # 异步尝试
    return True


class StaffRoleRequiredMixin(AccessMixin):
    env_settings = settings.ENV_TYPE

    def dispatch(self, request, *args, **kwargs):
        url_name = self.request.resolver_match.url_name
        for group in self.request.user.groups.all():
            for staff_permission in group.staffpermission_set.all():
                if staff_permission.allowed_url_name == 'all' \
                        or staff_permission.allowed_url_name == url_name:
                    return super(StaffRoleRequiredMixin, self).dispatch(request, *args, **kwargs)

        return HttpResponse("Not Allowed.", status=403)

    def get_context_data(self, **kwargs):
        context = super(StaffRoleRequiredMixin, self).get_context_data(**kwargs)
        context['env'] = self.env_settings
        return context


class BaseStaffView(StaffRoleRequiredMixin, TemplateView):
    """
    Base view for staff management page views.
    """

    @method_decorator(mala_staff_required)
    def dispatch(self, request, *args, **kwargs):
        return super(BaseStaffView, self).dispatch(request, *args, **kwargs)

    @property
    def school_master(self):
        # check the operate is school master or superuser
        # will filter data if school master logged in
        is_school_master = models.SchoolMaster.objects.filter(
            user=self.request.user).exists()
        if is_school_master:
            return self.request.user.schoolmaster
        return None


class BaseStaffActionView(StaffRoleRequiredMixin, View):
    """
    Base view for staff management action views.
    """

    default_err_msg = "操作失败,请稍后重试或联系管理员"

    # @method_decorator(csrf_exempt) # 不加csrf,不允许跨域访问
    @method_decorator(mala_staff_required)
    def dispatch(self, request, *args, **kwargs):
        return super(BaseStaffActionView, self).dispatch(request, *args, **kwargs)


#因为使用了listView而无法直接继承BaseStaffView
@method_decorator(mala_staff_required, name='dispatch')
class CouponsListView(StaffRoleRequiredMixin, ListView):
    model = models.Coupon
    template_name = 'staff/coupon/coupons_list.html'
    context_object_name = 'coupons_list'
    paginate_by = 10

    def get_context_data(self, **kwargs):
        context = super(CouponsListView, self).get_context_data(**kwargs)
        context['statusList'] = [
            {'text':"状态",'value':""},
            {'text':"已使用",'value':"used"},
            {'text':"未使用",'value':"unused"},
            {'text':"已过期",'value':"expired"},
                                ]
        context['typesList'] = [
            {'text':"类型",'value':""},
            {'text':"注册",'value':"reg"},
            {'text':"抽奖",'value':"lotto"},
                                ]
        context['name'] = self.request.GET.get('name', '')
        context['phone'] = self.request.GET.get('phone', '')
        context['dateFrom'] = self.request.GET.get('dateFrom', '')
        context['dateTo'] = self.request.GET.get('dateTo', '')
        context['type'] = self.request.GET.get('type', '')
        context['req_status'] = self.request.GET.get('status', '')
        page_obj = context.get('page_obj')
        if page_obj:
            paginator = page_obj.paginator
            context['pager'] = Pager(page_obj.number, paginator.num_pages, paginator.count, self.paginate_by)
        return context

    def get_queryset(self):
        coupons_list = self.model.objects.all()
        #TODO:用字典循环取值
        # for keyword in ['name','phone','dateFrom','dateTo','type','status']:
        #     cmd = "%s = self.request.GET.get('%s')" % (keyword,keyword)
        #     exec(cmd)
        #     print(name)
        name = self.request.GET.get('name')
        phone = self.request.GET.get('phone')
        dateFrom = self.request.GET.get('dateFrom')
        dateTo = self.request.GET.get('dateTo')
        type = self.request.GET.get('type')
        status = self.request.GET.get('status')

        if name:
            coupons_list = coupons_list.filter(parent__student_name__icontains=name)
        if phone:
            coupons_list = coupons_list.filter(parent__user__profile__phone__contains=phone)
        # if dateFrom:
        #     now = timezone.now()
        #     if not dateTo:
        #         dateTo = now
        #     print(dateFrom,dateTo)
        #     coupons_list = coupons_list.filter(created_at__range=(dateFrom, dateTo))
        if dateFrom:
            try:
                date_from = parse_date(dateFrom)
                coupons_list = coupons_list.filter(created_at__gte = date_from)
            except Exception as e:
                pass
        if dateTo:
            try:
                date_to = parse_date_next(dateTo)
                coupons_list = coupons_list.filter(created_at__lt = date_to)
            except Exception as e:
                pass
        if type == 'reg':
            pass
        if type == 'reg':
            pass
        if status == 'used':
            coupons_list = coupons_list.filter(used = True)
        if status == 'unused':
            now = timezone.now()
            coupons_list = coupons_list.filter(used = False).exclude(expired_at__lt = now)
        if status == 'expired':
            now = timezone.now()
            coupons_list = coupons_list.filter(used = False).filter(expired_at__lt = now)
        return coupons_list


class AnalysisView(BaseStaffView):
    template_name = 'staff/analysis.html'

    def get(self, request):
        context = dict(
                teachers=models.Teacher.objects.count(),
                parents=models.Parent.objects.count(),
                orders=models.Order.objects.filter(status=models.Order.PAID, to_pay__gt=1000).count(),
                )
        return render(request, self.template_name, context)


class TeacherView(BaseStaffView):
    template_name = 'staff/teacher/teachers.html'

    def get_context_data(self, **kwargs):
        # 把查询参数数据放到kwargs['query_data'], 以便template回显
        kwargs['query_data'] = self.request.GET.dict()
        #
        name = self.request.GET.get('name')
        phone = self.request.GET.get('phone')
        status = self.request.GET.get('status')
        reg_date_from = self.request.GET.get('reg_date_from')
        reg_date_to = self.request.GET.get('reg_date_to')
        region = self.request.GET.get('region')
        page = self.request.GET.get('page')
        query_set = models.Teacher.objects.filter()
        if name:
            query_set = query_set.filter(name__icontains = name)
        if phone:
            query_set = query_set.filter(user__profile__phone__contains = phone)
        if status and status.isdigit():
            query_set = query_set.filter(status = status)
        if reg_date_from:
            try:
                date_from = parse_date(reg_date_from)
                query_set = query_set.filter(user__date_joined__gte = date_from)
            except Exception as e:
                pass
        if reg_date_to:
            try:
                date_to = parse_date_next(reg_date_to)
                query_set = query_set.filter(user__date_joined__lt = date_to)
            except Exception as e:
                pass
        if region and region.isdigit():
            query_set = query_set.filter(region_id = region)
        query_set = query_set.order_by('-user__date_joined')
        # paginate
        query_set, pager = paginate(query_set, page)
        kwargs['teachers'] = query_set
        kwargs['pager'] = pager
        # 一些固定数据
        kwargs['status_choices'] = models.Teacher.STATUS_CHOICES
        kwargs['region_list'] = models.Region.objects.filter(Q(opened=True)|Q(name='其他'))
        return super(TeacherView, self).get_context_data(**kwargs)


class TeacherUnpublishedView(BaseStaffView):
    """
    待上架老师列表view
    """
    template_name = 'staff/teacher/teachers_unpublished.html'
    list_type = 'unpublished'

    def get_context_data(self, **kwargs):
        kwargs['list_type'] = self.list_type
        # 把查询参数数据放到kwargs['query_data'], 以便template回显
        kwargs['query_data'] = self.request.GET.dict()
        #
        name = self.request.GET.get('name') and self.request.GET.get('name').strip() or ''
        phone = self.request.GET.get('phone') and self.request.GET.get('phone').strip() or ''
        # province = self.request.GET.get('province')
        # city = self.request.GET.get('city')
        # district = self.request.GET.get('district')
        # region = district and district or city and city or province
        region = self.request.GET.get('region')
        grade = self.request.GET.get('grade') and self.request.GET.get('grade').strip() or ''
        subject = self.request.GET.get('subject') and self.request.GET.get('subject').strip() or ''
        level = self.request.GET.get('level') and self.request.GET.get('level').strip() or ''
        page = self.request.GET.get('page') and self.request.GET.get('page').strip() or ''
        for_published = self.list_type == 'published'
        query_set = models.Teacher.objects.filter(status=models.Teacher.INTERVIEW_OK, published=for_published)
        if self.school_master is not None:
            query_set = query_set.filter(schools=self.school_master.school)
        if name:
            query_set = query_set.filter(name__icontains=name)
        if phone:
            query_set = query_set.filter(user__profile__phone__contains=phone)
        if region:
            query_set = query_set.filter(region_id=region)
        if grade:
            query_set = query_set.filter(Q(abilities__grade_id=grade) | Q(abilities__grade__superset_id=grade))
        if subject:
            query_set = query_set.filter(abilities__subject_id=subject)
        if level:
            query_set = query_set.filter(level_id=level)
        query_set = query_set.order_by('id')
        query_set = query_set.distinct()
        # paginate
        query_set, pager = paginate(query_set, page, 15)
        kwargs['teachers'] = query_set
        kwargs['pager'] = pager
        # 一些固定数据
        # kwargs['provinces'] = models.Region.objects.filter(superset_id__isnull=True)
        kwargs['region_list'] = models.Region.objects.filter(Q(opened=True)|Q(name='其他'))
        kwargs['grades'] = models.Grade.objects.filter(superset_id__isnull=True)
        kwargs['subjects'] = models.Subject.objects.all
        kwargs['levels'] = models.Level.objects.all
        return super(TeacherUnpublishedView, self).get_context_data(**kwargs)


class TeacherPublishedView(TeacherUnpublishedView):
    """
    已上架老师列表view
    """
    list_type = 'published'
    def get_context_data(self, **kwargs):
        return super(TeacherPublishedView, self).get_context_data(**kwargs)


class TeacherUnpublishedEditView(BaseStaffView):
    """
    待上架老师编辑页面view
    """
    template_name = 'staff/teacher/teachers_unpublished_edit.html'

    def get_context_data(self, **kwargs):
        teacher_id = kwargs['tid']
        teacher = get_object_or_404(models.Teacher, id=teacher_id)
        kwargs['teacher'] = teacher
        # 老师科目年级
        curSubject = teacher.subject()
        if curSubject:
            kwargs['grade_ids_range'] = models.Ability.objects.filter(subject=curSubject).values_list('grade_id', flat=True)
        kwargs['teacher_grade_ids'] = [grade.id for grade in teacher.grades()]
        # 证书数据
        certification_all = models.Certificate.objects.filter(teacher=teacher)
        cert_others = []
        for cert in certification_all:
            if cert.type == models.Certificate.ID_HELD:
                kwargs['cert_id_held'] = cert
            elif cert.type == models.Certificate.ID_FRONT:
                kwargs['cert_id_front'] = cert
            elif cert.type == models.Certificate.ACADEMIC:
                kwargs['cert_academic'] = cert
            elif cert.type == models.Certificate.TEACHING:
                kwargs['cert_teaching'] = cert
            elif cert.type == models.Certificate.ENGLISH:
                kwargs['cert_english'] = cert
            else:
                cert_others.append(cert)
        kwargs['cert_others'] = cert_others
        # 地区数据
        # region_dict = teacher.region and teacher.region.make_dict() or None
        # kwargs['region_dict'] = region_dict
        # kwargs['provinces'] = models.Region.objects.filter(superset_id__isnull=True)
        # if region_dict and region_dict.get('city'):
        #     kwargs['cities'] = models.Region.objects.filter(superset_id=region_dict.get('city').superset_id)
        # if region_dict and region_dict.get('district'):
        #     kwargs['districts'] = models.Region.objects.filter(superset_id=region_dict.get('district').superset_id)
        kwargs['region_list'] = models.Region.objects.filter(Q(opened=True))
        if teacher.region:
            kwargs['teacher_schools'] = teacher.schools.all()
            kwargs['region_schools'] = models.School.objects.filter(region=teacher.region, opened=True)
        # 一些固定数据
        kwargs['gender_choices'] = models.Profile.GENDER_CHOICES
        kwargs['subjects'] = models.Subject.objects.all
        kwargs['levels'] = models.Level.objects.all
        grades_all = models.Grade.objects.all().order_by('-superset_id')
        _heap = {}
        grades_tree = []
        for grade in grades_all:
            if not grade.superset_id:
                _temp = {'id':grade.id, 'name':grade.name, 'children':[]}
                _heap[grade.id] = _temp
                grades_tree.append(_temp)
            else:
                _temp = _heap[grade.superset_id]
                _temp['children'].append({'id':grade.id, 'name':grade.name})
        kwargs['grades_tree'] = grades_tree
        kwargs['tags_all'] = models.Tag.objects.all
        return super(TeacherUnpublishedEditView, self).get_context_data(**kwargs)

    def post(self, request, tid):
        teacher = get_object_or_404(models.Teacher, id=tid)
        try:
            # 获取参数, 并检验
            newSubjectId = parseInt(request.POST.get('subject'), False)
            if not newSubjectId:
                return JsonResponse({'ok': False, 'msg': '请选择科目', 'code': 1})
            newGradeIds = request.POST.getlist('grade')
            if not newGradeIds:
                return JsonResponse({'ok': False, 'msg': '请选择年级', 'code': -1})
            newTagIds  = request.POST.getlist('tag')
            if not newTagIds or len(newTagIds)>3:
                return JsonResponse({'ok': False, 'msg': '风格标记 (最少选一个，最多选3个)', 'code': -1})
            certIdHeldOk = request.POST.get('certIdHeldOk')
            id_num = request.POST.get('id_num')
            if certIdHeldOk and certIdHeldOk=='True' and not check_id_number(id_num):
                return JsonResponse({'ok': False, 'msg': '身份认证失败, 身份证号不合法', 'code': -1})

            certIdHeld, created = models.Certificate.objects.get_or_create(teacher=teacher, type=models.Certificate.ID_HELD,
                                                                  defaults={'name':"",'verified':False})
            profile = teacher.user.profile
            # 基本信息
            teacher.name = request.POST.get('name')
            certIdHeld.name = id_num
            profile.phone = request.POST.get('phone')
            profile.gender = request.POST.get('gender')
            # province = request.POST.get('province')
            # city = request.POST.get('city')
            # district = request.POST.get('district')
            # region = district and district or city and city or province
            region = parseInt(request.POST.get('region'), None)
            if not region:
                teacher.region = None
            else:
                teacher.region_id = region
            # school_ids = request.POST.getlist('schools')
            # teacher.schools.clear()
            # if school_ids and len(school_ids) > 0:
            #     schools_qset = models.School.objects.filter(id__in=school_ids)
            #     for sch in schools_qset:
            #         teacher.schools.add(sch)
            #     teacher.save()
            teacher.teaching_age = parseInt(request.POST.get('teaching_age'), 0)
            # 更改成带有日志的模式
            new_level = models.Level.objects.get(pk=parseInt(request.POST.get('level'), 1))
            teacher.set_level(new_level)

            # teacher.level_id = parseInt(request.POST.get('level'), 1)

            teacher.experience = parseInt(request.POST.get('experience'), 0)
            teacher.profession = parseInt(request.POST.get('profession'), 0)
            teacher.interaction = parseInt(request.POST.get('interaction'), 0)
            # 是否在微信上显示
            show_on_wechat = request.POST.get('show_on_wechat')
            if show_on_wechat:  # if None: do not change
                teacher.recommended_on_wechat = (show_on_wechat == '1')
            # 是否为双师助教
            is_assistant = request.POST.get('is_assistant')
            if is_assistant:  # if None: do not change
                teacher.is_assistant = (is_assistant == '1')
            certIdHeld.save()
            # 科目年级 & 风格标签
            teacher.abilities.clear()
            ability_set = models.Ability.objects.filter(subject_id=newSubjectId, grade_id__in=newGradeIds)
            for ability in ability_set:
                teacher.abilities.add(ability)
            teacher.tags.clear()
            tag_set = models.Tag.objects.filter(id__in=newTagIds)
            for tag in tag_set:
                teacher.tags.add(tag)
            teacher.save()
            # 头像 & 照片
            avatarImg = None
            if request.FILES:
                avatarImg = request.FILES.get('avatarImg')
            if avatarImg:
                _img_content = ContentFile(avatarImg.read())
                profile.avatar.save("avatar"+str(teacher.id)+'_'+str(_img_content.size), _img_content)
            else:
                if request.POST.get('toDeleteAvatar'):
                    profile.avatar.delete()
            profile.save()
            stayPhotoIds = request.POST.getlist('photoId')
            stayPhotoIds = [i for i in stayPhotoIds if i]
            newPhotoImgs = request.FILES.getlist('photoImg')
            models.Photo.objects.filter(teacher_id=teacher.id).exclude(id__in=stayPhotoIds).delete()
            for photoImg in newPhotoImgs:
                photo = models.Photo(teacher=teacher, public=True)
                _img_content = ContentFile(photoImg.read())
                photo.img.save("photo"+str(teacher.id)+'_'+str(_img_content.size), _img_content)
                photo.save()
            # 提分榜
            allHsIds = request.POST.getlist('highscoreId')
            stayHsIds = [s for s in allHsIds if s and (not s.startswith('new'))]
            newHsIds = [s for s in allHsIds if s.startswith('new')]
            models.Highscore.objects.filter(teacher_id=teacher.id).exclude(id__in=stayHsIds).delete()
            for hsId in newHsIds:
                name = request.POST.get(hsId+'name')
                scores = request.POST.get(hsId+'scores')
                school_from = request.POST.get(hsId+'from')
                school_to = request.POST.get(hsId+'to')
                highscore = models.Highscore(teacher=teacher, name=name, increased_scores=scores,
                                             school_name=school_from, admitted_to=school_to)
                highscore.save()
            ### 认证
            # 身份认证
            oldCertIdVerify = certIdHeld.verified
            if certIdHeldOk and certIdHeldOk=='True':
                verified = certIdHeld.verified
                certIdHeld.verified = True
                if not verified:
                    certIdHeld.show_hint = True
            elif certIdHeldOk and certIdHeldOk=='Fail':
                fail = certIdHeld.audited and not certIdHeld.verified
                certIdHeld.audited = True
                certIdHeld.verified = False
                if not fail:
                    certIdHeld.show_hint = True
            else:
                certIdHeld.verified = False
            certIdHeldImg = None
            if request.FILES:
                certIdHeldImg = request.FILES.get('certIdHeldImg')
            if certIdHeldImg:
                _img_content = ContentFile(certIdHeldImg.read())
                certIdHeld.img.save("idHeld"+str(teacher.id)+'_'+str(_img_content.size), _img_content)
            else:
                if request.POST.get('toDeleteCertIdHeld'):
                    certIdHeld.img.delete()
            if not certIdHeld.img:
                certIdHeld.verified = False
            certIdFront, created = models.Certificate.objects.get_or_create(teacher=teacher, type=models.Certificate.ID_FRONT,
                                                              defaults={'name':"",'verified':False})
            certIdFrontImg = None
            if request.FILES:
                certIdFrontImg = request.FILES.get('certIdFrontImg')
            if certIdFrontImg:
                _img_content = ContentFile(certIdFrontImg.read())
                certIdFront.img.save("IdFront"+str(teacher.id)+'_'+str(_img_content.size), _img_content)
            else:
                if request.POST.get('toDeleteCertIdFront'):
                    certIdFront.img.delete()
            if not certIdFront.img:
                certIdHeld.verified = False
            certIdFront.save()
            certIdHeld.save()
            if oldCertIdVerify != certIdHeld.verified:
                # send notice (sms) to teacher, when verified value is changed
                self._send_cert_sms_notify('身份认证', certIdHeld.verified, profile.phone)
            # 学历, 教师资格证,英语水平
            self.post_save_cert(request, teacher, models.Certificate.ACADEMIC, 'Academic')
            self.post_save_cert(request, teacher, models.Certificate.TEACHING, 'Teaching')
            self.post_save_cert(request, teacher, models.Certificate.ENGLISH, 'English')
            # 其他认证
            allCertOtherIds = request.POST.getlist('certOtherId')
            stayCertOtherIds = [s for s in allCertOtherIds if s and (not s.startswith('new'))]
            newCertOtherIds = [s for s in allCertOtherIds if s.startswith('new')]
            models.Certificate.objects.filter(teacher=teacher, type=models.Certificate.OTHER)\
                .exclude(id__in=stayCertOtherIds).delete()
            for certId in stayCertOtherIds:
                name = request.POST.get(certId+'certName')
                cert_ok = request.POST.get(certId+'cert_ok')
                cert_img = None
                if request.FILES:
                    cert_img = request.FILES.get(certId+'cert_img')
                cert = models.Certificate.objects.get(id=certId)
                oldCertVerify = cert.verified
                cert.name = name
                if cert_ok and cert_ok=='True':
                    cert.verified = True
                elif cert_ok and cert_ok=='Fail':
                    cert.audited = True
                    cert.verified = False
                else:
                    cert.verified = False
                if cert_img:
                    _img_content = ContentFile(cert_img.read())
                    cert.img.save("certOther"+str(teacher.id)+'_'+str(_img_content.size), _img_content)
                cert.save()
                if oldCertVerify != cert.verified:
                    # send notice (sms) to teacher, when verified value is changed
                    self._send_cert_sms_notify('其他证书"'+cert.name+'"', cert.verified, profile.phone)
            for certId in newCertOtherIds:
                name = request.POST.get(certId+'certName')
                cert_ok = request.POST.get(certId+'cert_ok')
                cert_img = None
                if request.FILES:
                    cert_img = request.FILES.get(certId+'cert_img')
                if not cert_img:
                    continue
                newCert = models.Certificate(teacher=teacher,name=name,type=models.Certificate.OTHER,verified=False)
                if cert_ok and cert_ok=='True':
                    newCert.verified = True
                elif cert_ok and cert_ok=='Fail':
                    newCert.audited = True
                    newCert.verified = False
                _img_content = ContentFile(cert_img.read())
                newCert.img.save("certOther"+str(teacher.id)+'_'+str(_img_content.size), _img_content)
                newCert.save()
                if newCert.verified:
                    # send notice (sms) to teacher, when verified value is changed
                    self._send_cert_sms_notify('其他证书"'+newCert.name+'"', newCert.verified, profile.phone)
            # 介绍语音, 介绍视频
            introAudio = None
            if request.FILES:
                introAudio =  request.FILES.get('introAudio')
            if introAudio:
                _tmp_content = ContentFile(introAudio.read())
                teacher.audio.save('introAudio'+str(teacher.id)+'_'+str(_tmp_content.size), _tmp_content)
            else:
                if request.POST.get('toDeleteAudio'):
                    teacher.audio.delete()
            introVideo = None
            if request.FILES:
                introVideo =  request.FILES.get('introVideo')
            if introVideo:
                _tmp_content = ContentFile(introVideo.read())
                teacher.video.save('introVideo'+str(teacher.id)+'_'+str(_tmp_content.size), _tmp_content)
            else:
                if request.POST.get('toDeleteVideo'):
                    teacher.video.delete()
            teacher.save()
            # 教学成果
            allAchieveIds = request.POST.getlist('achieveId')
            stayAchieveIds = [s for s in allAchieveIds if s and (not s.startswith('new'))]
            newAchieveIds = [s for s in allAchieveIds if s.startswith('new')]
            models.Achievement.objects.filter(teacher=teacher).exclude(id__in=stayAchieveIds).delete()
            for achId in stayAchieveIds:
                title = request.POST.get(achId+'achieveName')
                achieveImg = None
                if request.FILES:
                    achieveImg = request.FILES.get(achId+'achieveImg')
                achievement = models.Achievement.objects.get(id=achId)
                achievement.title = title
                if achieveImg:
                    _img_content = ContentFile(achieveImg.read())
                    achievement.img.save("achievement"+str(teacher.id)+'_'+str(_img_content.size), _img_content)
                achievement.save()
            for achId in newAchieveIds:
                title = request.POST.get(achId+'achieveName')
                achieveImg = None
                if request.FILES:
                    achieveImg = request.FILES.get(achId+'achieveImg')
                if not title or not achieveImg:
                    continue
                newAch = models.Achievement(teacher=teacher,title=title)
                _img_content = ContentFile(achieveImg.read())
                newAch.img.save("achievement"+str(teacher.id)+'_'+str(_img_content.size), _img_content)
                newAch.save()
        except Exception as ex:
            logger.error(ex)
            return JsonResponse({'ok': False, 'msg': BaseStaffActionView.default_err_msg, 'code': -1})
        return JsonResponse({'ok': True, 'msg': '', 'code': 0})

    def post_save_cert(self, request, teacher, type_code, type_str, cert=None):
        if not cert:
            cert, created = models.Certificate.objects.get_or_create(teacher=teacher, type=type_code,
                                                                     defaults={'name':"",'verified':False})
        oldCertVerify = cert.verified
        cert_ok = request.POST.get('cert'+type_str+'Ok')
        if cert_ok and cert_ok=='True':
            verified = cert.verified
            cert.verified = True
            if not verified:
                cert.show_hint = True
        elif cert_ok and cert_ok=='Fail':
            fail = cert.audited and not cert.verified
            cert.audited = True
            cert.verified = False
            if not fail:
                cert.show_hint = True
        else:
            cert.verified = False
        cert_img = None
        if request.FILES:
            cert_img = request.FILES.get('cert'+type_str+'Img')
        if cert_img:
            _img_content = ContentFile(cert_img.read())
            cert.img.save(type_str+str(teacher.id)+'_'+str(_img_content.size), _img_content)
        else:
            if request.POST.get('toDeleteCert'+type_str):
                cert.img.delete()
        if not cert.img:
            cert.verified = False
        cert.save()
        cert_name = cert.get_type_display()
        if oldCertVerify != cert.verified:
            # send notice (sms) to teacher, when verified value is changed
            self._send_cert_sms_notify(cert_name, cert.verified, teacher.user.profile.phone)

    def _send_cert_sms_notify(self, cert_name, new_status, phone):
        # TODO:
        pass


class TeacherBankcardView(BaseStaffView):
    template_name = 'staff/teacher/teacher_bankcard_list.html'

    def get_context_data(self, **kwargs):
        # 把查询参数数据放到kwargs['query_data'], 以便template回显
        query_data = dict()
        query_data['name'] = self.request.GET.get('name', '')
        query_data['phone'] = self.request.GET.get('phone', '')
        kwargs['query_data'] = query_data
        #
        name = self.request.GET.get('name')
        phone = self.request.GET.get('phone')
        page = self.request.GET.get('page')
        query_set = models.BankCard.objects.select_related('account__user__teacher', 'account__user__profile').filter(account__user__teacher__isnull=False)
        if name:
            query_set = query_set.filter(account__user__teacher__name__contains = name)
        if phone:
            query_set = query_set.filter(account__user__profile__phone__contains = phone)
        query_set = query_set.order_by('account__user__teacher__name')
        # paginate
        query_set, pager = paginate(query_set, page)
        kwargs['bankcards'] = query_set
        kwargs['pager'] = pager
        return super(TeacherBankcardView, self).get_context_data(**kwargs)


class TeacherIncomeView(BaseStaffView):
    template_name = 'staff/teacher/teacher_income_list.html'

    def get_context_data(self, **kwargs):
        # 把查询参数数据放到kwargs['query_data'], 以便template回显
        query_data = {}
        query_data['name'] = self.request.GET.get('name', '')
        query_data['phone'] = self.request.GET.get('phone', '')
        kwargs['query_data'] = query_data
        #
        name = self.request.GET.get('name')
        phone = self.request.GET.get('phone')
        page = self.request.GET.get('page')
        query_set = models.Account.objects.select_related('user__teacher', 'user__profile').filter(user__teacher__isnull=False)
        if name:
            query_set = query_set.filter(user__teacher__name__contains = name)
        if phone:
            query_set = query_set.filter(user__profile__phone__contains = phone)
        query_set = query_set.order_by('user__teacher__name')
        # paginate
        query_set, pager = paginate(query_set, page)
        kwargs['accounts'] = query_set
        kwargs['pager'] = pager
        return super(TeacherIncomeView, self).get_context_data(**kwargs)

    def get(self, request, *args, **kwargs):
        export = request.GET.get('export')
        if export == 'true':
            name = self.request.GET.get('name')
            phone = self.request.GET.get('phone')
            query_set = models.Account.objects.select_related('user__teacher', 'user__profile').filter(user__teacher__isnull=False)
            if name:
                query_set = query_set.filter(user__teacher__name__contains = name)
            if phone:
                query_set = query_set.filter(user__profile__phone__contains = phone)
            query_set = query_set.order_by('user__teacher__name')
            headers = ('老师姓名', '手机号', '授课年级', '科目', '所在地区', '账户余额', '可提现金额', '累计收入',)
            columns = ('user.teacher.name',
                       'user.profile.phone',
                       'user.teacher.grades',
                       'user.teacher.subject',
                       'user.teacher.region.full_name',
                       lambda x: (x.calculated_balance/100),
                       lambda x: (x.calculated_balance/100),
                       lambda x: (x.accumulated_income/100),
                       )
            return excel.excel_response(query_set, columns, headers, '老师收入列表.xls')
        return super(TeacherIncomeView, self).get(request, *args, **kwargs)


class TeacherIncomeDetailView(BaseStaffView):
    """
    某个老师收入明细
    """
    template_name = 'staff/teacher/teacher_income_detail.html'

    def get_context_data(self, **kwargs):
        teacher_id = kwargs['tid']
        teacher = get_object_or_404(models.Teacher, id=teacher_id)
        kwargs['teacher'] = teacher
        query_data = {}
        query_data['date_from'] = self.request.GET.get('date_from', '')
        query_data['date_to'] = self.request.GET.get('date_to', '')
        query_data['order_id'] = self.request.GET.get('order_id', '')
        kwargs['query_data'] = query_data
        #
        date_from = self.request.GET.get('date_from', '')
        date_to = self.request.GET.get('date_to', '')
        order_id = self.request.GET.get('order_id', '')
        page = self.request.GET.get('page')
        account = teacher.safe_get_account()
        query_set = models.AccountHistory.objects.select_related('timeslot__order').filter(account=account, amount__gt=0)
        if date_from:
            try:
                date_from = parse_date(date_from)
                query_set = query_set.filter(submit_time__gte = date_from)
            except Exception as e:
                pass
        if date_to:
            try:
                date_to = parse_date_next(date_to)
                query_set = query_set.filter(submit_time__lt = date_to)
            except Exception as e:
                pass
        if order_id:
            query_set = query_set.filter(timeslot__order__order_id__icontains=order_id)
        query_set = query_set.order_by('-submit_time')
        # paginate
        query_set, pager = paginate(query_set, page)
        histories = self.arrange_by_day(query_set, account, order_id)
        kwargs['histories'] = histories
        kwargs['pager'] = pager
        return super(TeacherIncomeDetailView, self).get_context_data(**kwargs)

    def arrange_by_day(self, query_set, account, order_id):
        if len(query_set) == 0:
            return []
        min_time = None
        max_time = None
        for hist in query_set:
            the_time = hist.submit_time
            if min_time is None or min_time > the_time:
                min_time = the_time
            if max_time is None or max_time < the_time:
                max_time = the_time
        # query_set数据是分页已经被分页过的, 根据query_set的时间范围, 再次从数据库查询记录, 防止某天记录跨页情况
        date_from = min_time.replace(hour=0, minute=0, second=0, microsecond=0)
        date_to = max_time.replace(hour=0, minute=0, second=0, microsecond=0) + datetime.timedelta(days=1)
        new_query_set = models.AccountHistory.objects.select_related('timeslot__order')\
            .filter(account=account, amount__gt=0, submit_time__gte = date_from, submit_time__lt = date_to)
        if order_id:
            new_query_set = new_query_set.filter(timeslot__order__order_id__icontains=order_id)
        new_query_set = new_query_set.order_by('-submit_time')
        day_income_dict = {}
        for hist in new_query_set:
            the_day = hist.submit_time.replace(hour=0, minute=0, second=0, microsecond=0)
            day_income = day_income_dict.get(the_day)
            if day_income is None:
                day_income = hist.amount
            else:
                day_income += hist.amount
            day_income_dict[the_day] = day_income
        # 重新组织原来的query_set数据
        day_group = {}
        for hist in query_set:
            the_day = hist.submit_time.replace(hour=0, minute=0, second=0, microsecond=0)
            day_obj = day_group.get(the_day)
            if day_obj is None:
                day_obj = {}
                day_obj['count'] = 1
                day_obj['income'] = day_income_dict.get(the_day)
                day_obj['records'] = [hist]
                day_group[the_day] = day_obj
            else:
                day_obj['count'] += 1
                day_obj['records'].append(hist)
        histories = []
        for day, obj in day_group.items():
            obj['day'] = day
            histories.append(obj)
        histories.sort(key=lambda x: x['day'], reverse=True)
        return histories

    def _excel_of_histories(self, histories, filename):
        headers = ('日期', '订单号', '上课年级', '科目', '教师级别', '上课时间', '课时单价', '消耗课时', '佣金比例', '收入金额', '当日收入',)
        columns = (
            lambda x: x.timeslot and x.timeslot.order.order_id or (x.comment or '非课时收入'),
            'timeslot.order.grade',
            'timeslot.order.subject',
            'timeslot.order.level',
            lambda x: x.timeslot and ('%s-%s' % (x.timeslot.start.strftime('%H:%M'), x.timeslot.end.strftime('%H:%M'),)) or '',
            lambda x: x.timeslot and (x.timeslot.order.price / 100) or '',
            lambda x: x.timeslot and x.timeslot.duration_hours() or '',
            lambda x: x.timeslot and ('%s%%' % (x.timeslot.order.commission_percentage),) or '',
            lambda x: x.amount and (x.amount / 100) or '',
        )
        workbook = xlwt.Workbook()
        sheet_name = 'Export {0}'.format(datetime.date.today().strftime('%Y-%m-%d'))
        sheet = workbook.add_sheet(sheet_name)
        for y, th in enumerate(headers):
            sheet.write(0, y, th, excel.HEADER_STYLE)
        x = 1
        for history in histories:
            y = 0
            day_val = history['day'].date()
            sheet.write_merge(x, x + history['count'] - 1, y, y, day_val, excel.get_style_by_value(day_val))
            x_sub = x
            records = history['records']
            for record in records:
                y_sub = y+1
                for column in columns:
                    value = callable(column) and column(record) or excel.get_column_cell(record, column)
                    sheet.write(x_sub, y_sub, value, excel.get_style_by_value(value))
                    y_sub += 1
                x_sub += 1
            income = history['income'] / 100
            y += len(columns) + 1
            sheet.write_merge(x, x + history['count'] - 1, y, y, income, excel.get_style_by_value(income))
            x += len(records)
        return excel.wb_excel_response(workbook, filename)

    def get(self, request, *args, **kwargs):
        export = request.GET.get('export')
        if export == 'true':
            teacher_id = kwargs['tid']
            teacher = get_object_or_404(models.Teacher, id=teacher_id)
            #
            date_from = self.request.GET.get('date_from', '')
            date_to = self.request.GET.get('date_to', '')
            order_id = self.request.GET.get('order_id', '')
            account = teacher.safe_get_account()
            query_set = models.AccountHistory.objects.select_related('timeslot__order').filter(account=account, amount__gt=0)
            if date_from:
                try:
                    date_from = parse_date(date_from)
                    query_set = query_set.filter(submit_time__gte = date_from)
                except Exception as e:
                    pass
            if date_to:
                try:
                    date_to = parse_date_next(date_to)
                    query_set = query_set.filter(submit_time__lt = date_to)
                except Exception as e:
                    pass
            if order_id:
                query_set = query_set.filter(timeslot__order__order_id__icontains=order_id)
            query_set = query_set.order_by('-submit_time')
            histories = self.arrange_by_day(query_set, account, order_id)
            return self._excel_of_histories(histories, teacher.name+'老师收入明细列表.xls')
        return super(TeacherIncomeDetailView, self).get(request, *args, **kwargs)


class TeacherWithdrawalView(BaseStaffView):
    template_name = 'staff/teacher/teacher_withdrawal_list.html'

    def _get_query_set(self):
        date_from = self.request.GET.get('date_from')
        date_to = self.request.GET.get('date_to')
        status = self.request.GET.get('status')
        name = self.request.GET.get('name')
        phone = self.request.GET.get('phone')
        query_set = models.AccountHistory.objects.select_related('account__user__teacher', 'account__user__profile')\
            .filter(account__user__teacher__isnull=False, withdrawal__isnull=False)
        if date_from:
            try:
                date_from = parse_date(date_from)
                query_set = query_set.filter(submit_time__gte = date_from)
            except Exception as e:
                pass
        if date_to:
            try:
                date_to = parse_date_next(date_to)
                query_set = query_set.filter(submit_time__lt = date_to)
            except Exception as e:
                pass
        if status:
            query_set = query_set.filter(withdrawal__status = status)
        if name:
            query_set = query_set.filter(account__user__teacher__name__contains = name)
        if phone:
            query_set = query_set.filter(account__user__profile__phone__contains = phone)
        return query_set.order_by('-submit_time')

    def get_context_data(self, **kwargs):
        # 把查询参数数据放到kwargs['query_data'], 以便template回显
        query_data = {}
        query_data['name'] = self.request.GET.get('name', '')
        query_data['phone'] = self.request.GET.get('phone', '')
        query_data['date_from'] = self.request.GET.get('date_from')
        query_data['date_to'] = self.request.GET.get('date_to')
        query_data['status'] = self.request.GET.get('status')
        kwargs['query_data'] = query_data
        #
        query_set = self._get_query_set()
        # paginate
        page = self.request.GET.get('page')
        query_set, pager = paginate(query_set, page)
        kwargs['withdrawals'] = query_set
        kwargs['pager'] = pager
        # 一些固定数据
        kwargs['status_choices'] = models.Withdrawal.STATUS_CHOICES
        return super(TeacherWithdrawalView, self).get_context_data(**kwargs)

    def get(self, request, *args, **kwargs):
        export = request.GET.get('export')
        if export == 'true':
            query_set = self._get_query_set()
            headers = ('提现申请时间', '姓名', '手机号', '提现金额', '所在银行', '银行卡号', '开户行', '状态',)
            columns = (lambda x: timezone.make_naive(x.submit_time),
                       'account.user.teacher.name',
                       'account.user.profile.phone',
                       lambda x: (x.abs_amount/100),
                       'withdrawal.bankcard.bank_name',
                       'withdrawal.bankcard.card_number',
                       'withdrawal.bankcard.opening_bank',
                       'withdrawal.get_status_display',
                       )
            return excel.excel_response(query_set, columns, headers, '老师提现审核列表.xls')
        return super(TeacherWithdrawalView, self).get(request, *args, **kwargs)

    def post(self, request):
        action = self.request.POST.get('action')
        wid = self.request.POST.get('wid')
        if not wid:
            return JsonResponse({'ok': False, 'msg': '参数错误', 'code': 1})
        if action == 'approve':
            return self.approve_withdraw(request, wid)
        return HttpResponse("Not supported request.", status=403)

    def approve_withdraw(self, request, ahid):
        ok = False
        try:
            with transaction.atomic():
                ah = models.AccountHistory.objects.get(id=ahid)
                if not ah.withdrawal.is_pending():
                    return JsonResponse({'ok': False, 'msg': '已经被审核过了', 'code': -1})
                ah.audit_withdrawal(True, request.user)
                ok = True
        except IntegrityError as err:
            logger.error(err)
            return JsonResponse({'ok': False, 'msg': '操作失败, 请稍后重试或联系管理员', 'code': -1})
        if ok:
            # 短信通知老师
            teacher = ah.account.user.teacher
            _try_send_sms(teacher.user.profile.phone, smsUtil.TPL_WITHDRAW_APPROVE, {'username':teacher.name}, 2)
        return JsonResponse({'ok': True, 'msg': 'OK', 'code': 0})


class TeacherActionView(BaseStaffActionView):

    NO_TEACHER_FORMAT = "没有查到老师, ID={id}"

    def get(self, request):
        action = self.request.GET.get('action')
        if action == 'list-highscore':
            return self.get_teacher_highscore(request)
        if action == 'list-achievement':
            return self.get_teacher_achievement(request)
        if action == 'get-weekly-schedule':
            return self.get_teacher_weekly_schedule(request)
        if action == 'get-course-schedule':
            return self.get_teacher_course_schedule(request)
        if action == 'get-subject-grades-range':
            return self.get_grades_range_of_subject(request)
        return HttpResponse("", status=404)

    def post(self, request):
        action = self.request.POST.get('action')
        logger.debug("try to modify teacher, action = " + action)
        if action == 'donot-choose':
            return self.update_teacher_status(request, models.Teacher.NOT_CHOSEN)
        if action == 'invite-interview':
            return self.update_teacher_status(request, models.Teacher.TO_INTERVIEW)
        if action == 'set-interview-ok':
            return self.update_teacher_status(request, models.Teacher.INTERVIEW_OK)
        if action == 'set-interview-fail':
            return self.update_teacher_status(request, models.Teacher.INTERVIEW_FAIL)
        if action == 'publish-teacher':
            return self.publish_teacher(request);
        return HttpResponse("Not supported request.", status=403)

    def publish_teacher(self, request):
        tid = request.POST.get('tid')
        flag = request.POST.get('flag')
        if not tid or not flag in ['true', 'false']:
            return JsonResponse({'ok': False, 'msg': '参数错误', 'code': 1})
        try:
            teacher = models.Teacher.objects.get(id=tid)
            teacher.published = (flag == 'true')

            # 判断是否可以上架 BE-223
            errmsg = ""
            if teacher.published:
                # certification_all = models.Certificate.objects.filter(teacher=teacher)
                # for cert in certification_all:
                #     if cert.type == models.Certificate.ID_HELD:
                #         if cert.name is None or cert.name == '':
                #             errmsg += '身份证不能为空，'
                #         if not cert.verified:
                #             errmsg += '身份证照认证未通过，'
                #     elif cert.type == models.Certificate.ACADEMIC:
                #         if not cert.verified:
                #             errmsg += '学历证认证未通过，'
                #     elif cert.type == models.Certificate.TEACHING:  #教师资格
                #         pass
                #     elif cert.type == models.Certificate.ENGLISH:   #英语水平认证
                #         pass

                if teacher.name is None or teacher.name == '':
                    errmsg += '老师姓名不能为空，'

                profile = models.Profile.objects.get(user=teacher.user)
                if profile.phone is None or profile.phone == '':
                    errmsg += '手机号未填写，'
                if profile.gender not in [models.Profile.MALE, models.Profile.FEMALE]:
                    errmsg += '性别没有，'
                # if not profile.avatar or profile.avatar.url is None or profile.avatar.url == '':
                #     errmsg += '头像没有，'
                if not teacher.region or not teacher.region.id:
                    errmsg += '所在地区不能为空，'
                if not teacher.level or not teacher.level.id:
                    errmsg += '教师级别不能为空，'
                if teacher.subject() is None:
                    errmsg += '教授科目不能为空，'
                if teacher.grades() is None or len(teacher.grades()) == 0:
                    errmsg += '年级至少选择一个，'
                # if teacher.tags.all() is None or len(teacher.tags.all()) == 0:
                #     errmsg += '风格标记至少选择一个，'

                # highscores = models.Highscore.objects.filter(teacher=teacher)
                # if highscores.count() == 0:
                #     errmsg += '提分榜至少填一个，'

                if len(errmsg) > 0:
                    return JsonResponse({'ok': False, 'msg': errmsg, 'code': -1})

            teacher.save()
            # send notice (sms) to teacher
            phone = teacher.user.profile.phone
            if phone:
                sms_tpl_id = 0
                sms_data = None
                if teacher.published:
                    sms_tpl_id = smsUtil.TPL_PUBLISH_TEACHER
                    sms_data = {'username': teacher.name}
                else:
                    pass
                sms_ok = _try_send_sms(phone, sms_tpl_id, sms_data, 3)
                if not sms_ok:
                    ret_msg = '修改【'+teacher.name+'】老师状态成功, 但是短信通知失败, 请自行通知。'
                    return JsonResponse({'ok': True, 'msg': ret_msg, 'code': 3})
            return JsonResponse({'ok': True, 'msg': 'OK', 'code': 0})
        except models.Teacher.DoesNotExist as e:
            msg = self.NO_TEACHER_FORMAT.format(id=tid)
            logger.error(msg)
            return JsonResponse({'ok': False, 'msg': msg, 'code': 1})
        # except Exception as err:
        #     logger.error(err)
        #     return JsonResponse({'ok': False, 'msg': self.default_err_msg, 'code': -1})

    def get_teacher_highscore(self, request):
        """
        获取某个老师的提分榜列表
        :param request:
        :return:
        """
        tid = request.GET.get('tid')
        if not tid:
            return HttpResponse("")
        query_set = models.Highscore.objects.filter(teacher_id=tid)
        highscores = []
        for hs in query_set:
            highscores.append({'name': hs.name, 'scores': hs.increased_scores, 'from': hs.school_name, 'to': hs.admitted_to})
        return JsonResponse({'list': highscores})

    def get_teacher_achievement(self, request):
        """
        获取某个老师的特殊成果
        :param request:
        :return:
        """
        tid = request.GET.get('tid')
        if not tid:
            return HttpResponse("")
        query_set = models.Achievement.objects.filter(teacher_id=tid)
        achievements = []
        for ac in query_set:
            achievements.append({'title': ac.title, 'img': ac.img_url()})
        return JsonResponse({'list': achievements})

    def get_teacher_weekly_schedule(self, request):
        """
        获取某个老师的周时间表
        :param request:
        :return:
        """
        tid = request.GET.get('tid')
        if not tid:
            return HttpResponse("")
        teacher = get_object_or_404(models.Teacher, id=tid)
        weekly_time_slots = []
        for wts in teacher.weekly_time_slots.all():
            weekly_time_slots.append({'weekday': wts.weekday, 'start': wts.start, 'end': wts.end})
        return JsonResponse({'list': weekly_time_slots, 'dailyTimeSlots': models.WeeklyTimeSlot.DAILY_TIME_SLOTS(teacher.region)})

    def get_teacher_course_schedule(self, request):
        """
        查询老师某一周的课程安排
        :param request: 老师ID, 周偏移量
        :return: 课程记录
        """
        tid = request.GET.get('tid')
        week_offset = parseInt(request.GET.get('week_offset'), 0)
        if not tid:
            return HttpResponse("")
        teacher = get_object_or_404(models.Teacher, id=tid)
        # 每周时间计划
        weekly_time_slots = []
        for wts in teacher.weekly_time_slots.all():
            weekly_time_slots.append({'weekday': wts.weekday, 'start': wts.start, 'end': wts.end})
        # 计算该周日期
        now = timezone.now()
        from_day = now + datetime.timedelta(days=(-now.weekday()+week_offset*7))  # 该周一
        to_day = now + datetime.timedelta(days=(7-now.weekday()+week_offset*7))  # 下周一
        dates = []
        for i in range(7):
            _d = from_day + datetime.timedelta(days=i)
            dates.append(str(_d.month)+'.'+str(_d.day))
        # 查询课程安排
        from_time = from_day.replace(hour=0, minute=0, second=0, microsecond=0)
        to_time = to_day.replace(hour=0, minute=0, second=0, microsecond=0)
        time_slots = models.TimeSlot.objects.select_related("order__parent")\
            .filter(order__teacher_id=teacher.id,
                    start__gte=from_time,
                    end__lt=to_time,
                    deleted=False)
        courses = []
        TIME_FMT = '%H:%M:00'
        order_heap = {}
        # 组织课程信息, TODO: 调课退课退费记录
        for timeSlot in time_slots:
            ts_dict = {}
            ts_dict['weekday'] = timeSlot.start.isoweekday()
            ts_dict['start'] = timeSlot.start.strftime(TIME_FMT)
            ts_dict['end'] = timeSlot.end.strftime(TIME_FMT)
            cur_order = order_heap.get(timeSlot.order_id)
            if not cur_order:
                cur_order = {}
                cur_order['subject'] = timeSlot.order.grade.name+timeSlot.order.subject.name
                cur_order['phone'] = timeSlot.order.parent.user.profile.phone
                cur_order['student'] = timeSlot.order.parent.student_name
                cur_order['school'] = timeSlot.order.school.name
                order_heap[timeSlot.order_id] = cur_order
            ts_dict.update(cur_order)
            courses.append(ts_dict)
        return JsonResponse({'list': weekly_time_slots,
                             'dailyTimeSlots': models.WeeklyTimeSlot.DAILY_TIME_SLOTS(teacher.region),
                             'dates': dates, 'courses': courses})

    def get_grades_range_of_subject(self, request):
        """
        获取subject所属的的年级范围
        :param request:
        :return:
        """
        sid = request.GET.get('sid')  # subject id
        if not sid:
            return HttpResponse("")
        grade_ids = list(models.Ability.objects.filter(subject_id=sid).values_list('grade_id', flat=True))
        return JsonResponse({'list': grade_ids})

    def update_teacher_status(self, request, new_status):
        """
        新注册老师修改老师状态
        :param request:
        :param new_status:
        :return:
        """
        teacher_id = request.POST.get('teacher_id')
        try:
            teacher = models.Teacher.objects.get(id=teacher_id)
            # 用带日志的方法来包裹裸的调用
            teacher.set_status(request.user, new_status)
            # teacher.status = new_status
            teacher.save()
            # send notice (sms) to teacher
            phone = teacher.user.profile.phone
            if phone:
                sms_tpl_id = 0
                sms_data = None
                if new_status == models.Teacher.NOT_CHOSEN:
                    pass
                elif new_status == models.Teacher.TO_INTERVIEW:
                    pass # TODO: 短信模板没有做好
                elif new_status == models.Teacher.INTERVIEW_OK:
                    sms_tpl_id = smsUtil.TPL_INTERVIEW_OK
                    sms_data = {'username': teacher.name}
                elif new_status == models.Teacher.INTERVIEW_FAIL:
                    sms_tpl_id = smsUtil.TPL_INTERVIEW_FAIL
                    sms_data = {'username': teacher.name}
                else:
                    pass
                sms_ok = _try_send_sms(phone, sms_tpl_id, sms_data, 3)
                if not sms_ok:
                    ret_msg = '修改【'+teacher.name+'】老师状态成功, 但是短信通知失败, 请自行通知。'
                    return JsonResponse({'ok': True, 'msg': ret_msg, 'code': 3})
            return JsonResponse({'ok': True, 'msg': 'OK', 'code': 0})
        except models.Teacher.DoesNotExist as e:
            msg = self.NO_TEACHER_FORMAT.format(id=teacher_id)
            logger.error(msg)
            return JsonResponse({'ok': False, 'msg': msg, 'code': 1})
        except Exception as err:
            logger.error(err)
            return JsonResponse({'ok': False, 'msg': self.default_err_msg, 'code': -1})


class StudentView(BaseStaffView):
    template_name = 'staff/student/students.html'

    def get_context_data(self, **kwargs):
        kwargs['query_data'] = self.request.GET.dict()
        name = self.request.GET.get('name')
        phone = self.request.GET.get('phone')
        page = self.request.GET.get('page')
        parents = models.Parent.objects.all()
        # filter the data with order of the school
        if self.school_master is not None:
            parents = parents.filter(order__school=self.school_master.school)

        if name:
            parents = parents.filter(
                students__name__icontains=name).distinct()
        if phone:
            parents = parents.filter(
                user__profile__phone__contains=phone).distinct()

        parents = parents.order_by('-user__date_joined').distinct()
        count = parents.count()

        parents, pager = paginate(parents, page)
        page = pager.number
        for idx, parent in enumerate(parents):
            parent.idx = count - pager.page_size * (page - 1) - idx

        kwargs['parents'] = parents
        kwargs['pager'] = pager
        return super(StudentView, self).get_context_data(**kwargs)


class StudentScheduleManageView(BaseStaffView):
    template_name = 'staff/student/schedule_manage.html'

    def get_context_data(self, **kwargs):
        # 把查询参数数据放到kwargs['query_data'], 以便template回显
        kwargs['query_data'] = self.request.GET.dict()
        parent_phone = self.request.GET.get('phone')
        week = self.request.GET.get('week',0)
        week = int(week)
        kwargs['query_data']['week'] = week

        # deleted 代表已经释放和调课的, suspended 代表停课的, 这些都不显示
        query_set = models.TimeSlot.objects.filter(deleted=False, suspended=False)
        # make sure to only show time slots of this school for school master
        if self.school_master is not None:
            query_set = query_set.filter(order__school=self.school_master.school)
        # 家长手机号, 精确匹配
        if parent_phone:
            query_set = query_set.filter(order__parent__user__profile__phone=parent_phone)

        kwargs['all_count'] = query_set.count()

        # 起始查询时间: 根据当前天 和 上下几周 确定
        start_search_time = timezone.now().replace(hour=0, minute=0, second=0, microsecond=0)
        start_search_time += datetime.timedelta(days=week*7)

        # 结束时间
        end_search_time = start_search_time + datetime.timedelta(days=7)

        # 一周内 weekday 和 具体日期
        weekdays = []
        for i in range(7):
            weekdays_dict = {}
            date = start_search_time + datetime.timedelta(days=i)
            weekdays_dict['weekday'] = date.weekday() + 1
            weekdays_dict['date'] = date
            weekdays.append(weekdays_dict)

        # 只获取一周内数据
        query_set = query_set.filter(start__gte=start_search_time).filter(end__lte=end_search_time).order_by('start')

        # 从今天起到后7天的 weekday 描述
        kwargs['weekdays'] = weekdays
        kwargs['today'] = timezone.now().replace(hour=0, minute=0, second=0, microsecond=0)
        # 固定的 weekly time slots
        # TODO: super admin do not display the table for now
        kwargs['weekly_time_slots'] = []
        if self.school_master is not None:
            region = self.school_master.school.region
            weekly_time_slots = models.WeeklyTimeSlot.DAILY_TIME_SLOTS(region)
            kwargs['weekly_time_slots'] = weekly_time_slots

        # 查询结果数据集
        kwargs['timeslots'] = query_set
        kwargs['evaluations'] = models.Evaluation.objects.filter(
            start__gte=start_search_time,
            end__lte=end_search_time,
            status=models.Evaluation.SCHEDULED,
            order__parent__user__profile__phone=parent_phone)
        return super(StudentScheduleManageView, self).get_context_data(**kwargs)


class StudentScheduleChangelogView(BaseStaffView):
    template_name = 'staff/student/schedule_changelog.html'

    """
    已经调课停课课时(Timeslot)列表
    """
    def get_context_data(self, **kwargs):
        # 把查询参数数据放到kwargs['query_data'], 以便template回显
        kwargs['query_data'] = self.request.GET.dict()
        name = self.request.GET.get('name')
        phone = self.request.GET.get('phone')
        type = self.request.GET.get('type')
        searchDateOri = self.request.GET.get('searchDateOri')
        searchDateNew = self.request.GET.get('searchDateNew')
        page = self.request.GET.get('page')

        query_set = models.TimeSlotChangeLog.objects.all()
        # make sure to only show the changelog of this school for school master
        if self.school_master is not None:
            query_set = query_set.filter(
                old_timeslot__order__school=self.school_master.school)
        # 家长姓名 or 学生姓名 or 老师姓名, 模糊匹配
        if name:
            query_set = query_set.filter(
                Q(old_timeslot__order__parent__user__username__icontains=name) |
                Q(old_timeslot__order__parent__student_name__icontains=name) |
                Q(old_timeslot__order__teacher__name__icontains=name)
            )
        # 家长手机 or 老师手机, 模糊匹配
        if phone:
            query_set = query_set.filter(
                Q(old_timeslot__order__parent__user__profile__phone__contains=phone) |
                Q(old_timeslot__order__teacher__user__profile__phone__contains=phone)
            )
        # 类型匹配
        if type:
            query_set = query_set.filter(record_type=type)

        # 原上课时间
        if searchDateOri:
            stTime = datetime.datetime.strptime(searchDateOri, '%Y-%m-%d')
            query_set = query_set.filter(
                Q(old_timeslot__start__date=stTime.date())
            )

        # 现上课时间
        if searchDateNew:
            stTime = datetime.datetime.strptime(searchDateNew, '%Y-%m-%d')
            query_set = query_set.filter(
                Q(new_timeslot__start__date=stTime.date())
            )
        # 可用筛选条件数据集
        kwargs['types'] = models.TimeSlotChangeLog.TYPE_CHOICES
        # paginate
        query_set, pager = paginate(query_set, page)
        # 查询结果数据集
        kwargs['changelogs'] = query_set
        kwargs['pager'] = pager
        return super(StudentScheduleChangelogView, self).get_context_data(**kwargs)

    def get(self, request):
        context = self.get_context_data()
        return render(request, self.template_name, context)


class StudentScheduleActionView(BaseStaffActionView):
    def post(self, request):
        action = self.request.POST.get('action')
        if action == 'suspend-course':
            return self.suspend_course(request)
        if action == 'view-available':
            return self.view_available(request)
        if action == 'transfer-course':
            return self.transfer_course(request)
        return HttpResponse("Not supported action.", status=404)

    def suspend_course(self, request):
        tid = request.POST.get('tid')
        timeslot = models.TimeSlot.objects.get(id=tid)
        # 具体停课操作在里面
        if not timeslot.reschedule_for_suspend(self.request.user):
            return JsonResponse({'ok': False, 'msg': '停课失败, 请稍后重试或联系管理员', 'code': 'suspend_transaction'})
        return JsonResponse({'ok': True})

    def view_available(self, request):
        tid = request.POST.get('tid')
        timeslot = models.TimeSlot.objects.get(id=tid)
        teacher = timeslot.order.teacher
        school = timeslot.order.school
        sa_dict = teacher.shortterm_available_dict(school)

        data = [OrderedDict([
            ('weekday', one[0]),
            ('start', one[1]),
            ('end', one[2]),
            ('available', sa_dict[(one[0], one[1], one[2])])
        ]) for one in sa_dict]

        now_date = timezone.now().astimezone().strftime('%Y-%m-%d')
        now_time = timezone.now().astimezone().strftime('%H:%M:%S')

        return JsonResponse({'ok': True, 'sa_dict': data, 'now_date': now_date, 'now_time': now_time})

    def transfer_course(self, request):
        tid = request.POST.get('tid')
        new_date_str = request.POST.get('new_date')
        new_start_str = request.POST.get('new_start')
        new_end_str = request.POST.get('new_end')
        new_start_datetime = timezone.make_aware(
            datetime.datetime.strptime(new_date_str + ' ' + new_start_str, '%Y-%m-%d %H:%M:%S')
        )
        new_end_datetime = timezone.make_aware(
            datetime.datetime.strptime(new_date_str + ' ' + new_end_str, '%Y-%m-%d %H:%M:%S')
        )
        timeslot = models.TimeSlot.objects.get(id=tid)
        ret_code = timeslot.reschedule_for_transfer(new_start_datetime, new_end_datetime, self.request.user)

        if ret_code == -1:
            return JsonResponse({'ok': False, 'msg': '调课失败, 请稍后重试或联系管理员', 'code': 'transfer_transaction'})
        if ret_code == -2:
            return JsonResponse({'ok': False, 'msg': '调课失败, 调整后的课程时间冲突, 请稍后重试或联系管理员', 'code': 'transfer_conflict'})

        # JPush 通知
        extras = {
            "type": Remind.COURSE_CHANGED,  # 课程变动
            "code": None
        }

        old_start = timeslot.start.astimezone().strftime("%m月%d日%H:%M")
        old_end = timeslot.end.astimezone().strftime("%H:%M")
        new_start = new_start_datetime.astimezone().strftime("%m月%d日%H:%M")
        new_end = new_end_datetime.astimezone().strftime("%H:%M")
        subject = timeslot.order.subject.name
        grade = timeslot.order.grade.name
        msg = "您在%s-%s的%s%s课程已调整到%s-%s，快去看看吧" % (
            old_start,
            old_end,
            grade,
            subject,
            new_start,
            new_end)
        send_push.delay(
            msg,
            title=Remind.title(Remind.COURSE_CHANGED),
            user_ids=[timeslot.order.parent.user_id],
            extras=extras
        )

        # 短信通知家长
        old_date = "%s-%s" % (old_start, old_end)
        new_date = "%s-%s" % (new_start, new_end)
        grade_subject = grade + subject
        parent = timeslot.order.parent
        _try_send_sms(
            parent.user.profile.phone,
            smsUtil.TPL_STU_TRANSFER_COURSE,
            {'olddate': old_date,
             'subject': grade_subject,
             'newdate': new_date}, 3)
        # 短信通知老师
        teacher = timeslot.order.teacher
        _try_send_sms(
            teacher.user.profile.phone,
            smsUtil.TPL_TEA_TRANSFER_COURSE,
            {'olddate': old_date,
             'subject': grade_subject,
             'newdate': new_date}, 3)

        return JsonResponse({'ok': True})


class SchoolsView(BaseStaffView):
    template_name = 'staff/school/schools.html'

    def get_context_data(self, **kwargs):
        context = super(SchoolsView, self).get_context_data(**kwargs)
        schoolId = self.request.GET.get('schoolId')
        center = self.request.GET.get('center')

        query_set = models.School.objects.filter().order_by('-opened', '-id')
        if schoolId:
            query_set = query_set.filter(id = schoolId)

        if center == 1:
            query_set = query_set.filter(center = True)
        elif center == 2:
            query_set = query_set.filter(center = False)

        context['schools'] = query_set
        context['schoolId'] = schoolId
        context['center'] = center
        context['allSchools'] = models.School.objects.filter()
        return context


class SchoolView(BaseStaffView):
    template_name = 'staff/school/edit.html'

    def get_context_data(self, **kwargs):
        context = super(SchoolView, self).get_context_data(**kwargs)
        schoolId = self.request.GET.get('schoolId')
        memberservices = models.Memberservice.objects.all().values('id','name')
        if not schoolId:
            schoolId = self.request.POST.get('schoolId')

        if schoolId == 'None':
            schoolId = None

        context['region_list'] = models.Region.objects.filter(opened=True)
        context['schoolId'] = schoolId
        context['memberservices'] = memberservices
        return context

    def get(self, request):
        context = self.get_context_data()
        schoolId = context['schoolId']
        school = None
        if schoolId:
            school = models.School.objects.get(id=schoolId)

        context['school'] = school
        return render(request, self.template_name, context)

    def post(self, request):
        context = self.get_context_data()
        schoolId = context['schoolId']
        school = None
        if schoolId is not None:
            school = models.School.objects.get(id=schoolId)
        else:
            school = models.School()


        service_list = self.request.POST.getlist('services')


        school.phone = self.request.POST.get('phone')
        school.name = self.request.POST.get('schoolName')
        school.center = True if self.request.POST.get('center', '0') == '1' else False
        school.opened = True if self.request.POST.get('opened', '0') == '1' else False
        class_seat = self.request.POST.get('class_seat')
        if class_seat == '':
            class_seat = 0
        school.class_seat = class_seat
        study_seat = self.request.POST.get('study_seat')
        if study_seat == '':
            study_seat = 0
        share_rate = self.request.POST.get('share_rate')
        if share_rate == '' or int(share_rate) > 100 or int(share_rate) < 0:
            return JsonResponse({'ok': False, 'msg': '分成比例值错误', 'code': 4})
        school.share_rate = share_rate
        school.study_seat = study_seat
        school.longitude = self.request.POST.get('longitude')
        school.latitude = self.request.POST.get('latitude')
        school.address = self.request.POST.get('address')
        school.desc_title = self.request.POST.get('desc_title')
        school.desc_content = self.request.POST.get('desc_content')
        regionId = self.request.POST.get('regionId')
        school.region = models.Region.objects.get(id=regionId)
        school.save()
        school.member_services = service_list

        context['school'] = school

        staySchoolImgIds = request.POST.getlist('schoolImgId')
        staySchoolImgIds = [i for i in staySchoolImgIds if i]
        models.SchoolPhoto.objects.filter(school_id=schoolId).exclude(
            id__in=staySchoolImgIds).delete()
        newSchoolImgs = request.FILES.getlist('schoolImg')
        for index, schoolImg in enumerate(newSchoolImgs):
            photo = models.SchoolPhoto(school=school)
            _img_content = ContentFile(schoolImg.read())
            photo.img.save(
                "photo" + str(school.id) + '_' + str(_img_content.size),
                _img_content)
            photo.save()
            # 保存第一张图为API接口的缩略图
            if index == 0:
                school.thumbnail.save(
                    "photo" + str(school.id) + '_' + str(_img_content.size),
                    _img_content)

        # init the new school's prices
        school.init_prices()

        return JsonResponse({'ok': True, 'msg': 'OK', 'code': 0})


class OrderReviewView(BaseStaffView):
    template_name = 'staff/order/review.html'

    def get_context_data(self, **kwargs):

        # 把查询参数数据放到kwargs['query_data'], 以便template回显
        kwargs['query_data'] = self.request.GET.dict()
        name = self.request.GET.get('name')
        phone = self.request.GET.get('phone')
        order_id = self.request.GET.get('order_id')
        course_type = self.request.GET.get('type')
        status = self.request.GET.get('status')
        grade = self.request.GET.get('grade')
        subject = self.request.GET.get('subject')
        school = self.request.GET.get('school')
        order_date_from = self.request.GET.get('order_date_from')
        order_date_to = self.request.GET.get('order_date_to')
        page = self.request.GET.get('page')
        export = self.request.GET.get('export')

        query_set = models.Order.objects.filter()
        if self.school_master is not None:
            query_set = query_set.filter(school=self.school_master.school)
        # 家长姓名 or 学生姓名 or 老师姓名, 模糊匹配
        if name:
            query_set = query_set.filter(
                Q(parent__user__username__icontains=name) |
                Q(parent__students__name__icontains=name) |
                Q(teacher__name__icontains=name)
            ).distinct()
        # 家长手机 or 老师手机, 模糊匹配
        if phone:
            query_set = query_set.filter(
                Q(parent__user__profile__phone__contains=phone) |
                Q(teacher__user__profile__phone__contains=phone)
            )
        # 后台系统订单号, 模糊匹配
        if order_id:
            query_set = query_set.filter(order_id__icontains=order_id)
        # 课程类型
        if course_type:
            if course_type == '1to1':
                query_set = query_set.filter(live_class__isnull=True)
            elif course_type == 'lc':
                query_set = query_set.filter(live_class__isnull=False)
        # 订单状态
        if status:
            # 此处 status 是前端传过来的值, 需要进一步判断具体状态
            if status == models.Order.REFUND:
                # 退费成功:
                query_set = query_set.filter(
                    status=status,
                    refund_status=models.Order.REFUND_APPROVED,
                )
            elif status in [
                    models.Order.REFUND_PENDING, models.Order.REFUND_REJECTED]:
                # 退费审核中/退费被驳回: 最后审核状态
                query_set = query_set.filter(refund_status=status)
            else:
                """
                其他状态, 直接判断 order 状态: 未支付(PENDING)
                                           已支付(PAID)
                                           已取消(CANCELED)
                                           已结束(???)(最后一节课已经完成)
                """
                # todo: 缺少一个已结束的状态, 后续完善
                query_set = query_set.filter(status=status, refund_status__isnull=True)

        # 年级
        if grade:
            query_set = query_set.filter(grade=grade)
        # 科目
        if subject:
            query_set = query_set.filter(subject=subject)
        # 授课中心
        if school:
            query_set = query_set.filter(school=school)
        # 下单日期区间
        if order_date_from:
            try:
                date_from = parse_date(order_date_from)
                query_set = query_set.filter(created_at__gte=date_from)
            except Exception as e:
                pass
        if order_date_to:
            try:
                date_to = parse_date_next(order_date_to)
                query_set = query_set.filter(created_at__lt=date_to)
            except Exception as e:
                pass

        # 可用筛选条件数据集
        # 订单状态 + 退费审核状态
        all_status = models.Order.STATUS_CHOICES + models.Order.REFUND_STATUS_CHOICES
        # 去除 退费审核通过 和 审核被驳回 的状态, 前端不需要显示
        remove_status = [models.Order.REFUND_APPROVED, models.Order.REFUND_REJECTED]
        kwargs['status'] = []
        for key, text in all_status:
            if key in remove_status:
                continue
            else:
                kwargs['status'].append((key, text))
        kwargs['schools'] = models.School.objects.filter(opened=True)
        kwargs['grades'] = models.Grade.objects.all()
        kwargs['subjects'] = models.Subject.objects.all()
        # 查询结果数据集, 默认按下单时间排序
        query_set = query_set.order_by('-created_at')
        if export is not None:
            # 导出操作, 直接给 query_set
            return query_set
        # 非导出操作, 继续分页显示
        query_set, pager = paginate(query_set, page, 10)
        kwargs['orders'] = query_set
        kwargs['pager'] = pager
        return super(OrderReviewView, self).get_context_data(**kwargs)

    def get(self, request):
        context = self.get_context_data()
        export = self.request.GET.get('export')
        if export:
            query_set = context
            _weekday_dict = {
                1: "周一",
                2: "周二",
                3: "周三",
                4: "周四",
                5: "周五",
                6: "周六",
                7: "周日",
            }
            headers = (
                '订单号',
                '下单时间',
                '支付平台',
                '订单状态',
                '是否排课',
                '家长手机号',
                '学生姓名',
                '老师姓名',
                '老师手机号',
                '报课年级',
                '报课科目',
                '上课地点',
                '上课时间',
                '小时单价',
                '购买小时',
                '订单金额',
                '奖学金',
                '消耗小时',
                '消耗订单金额',
                '剩余小时',
                '剩余订单金额',
                '退费小时',
                '退费金额',
                '实际上课小时',
                '实际订单金额',
            )
            columns = (
                'order_id',
                lambda x: timezone.make_naive(x.created_at),
                lambda x: '\n'.join(c.channel for c in x.charge_set.all()),
                'status_display',
                lambda x: '是' if x.is_timeslot_allocated() else '否',
                'parent.user.profile.phone',
                'parent.student_name',
                'teacher.name',
                'teacher.user.profile.phone',
                'grade',
                'subject',
                'school',
                lambda x: '\n'.join(
                    _weekday_dict.get(w.weekday, '') +
                    w.start.strftime('%H:%M') +
                    '-' +
                    w.end.strftime('%H:%M')
                    for w in x.weekly_time_slots.all()
                ),
                lambda x: x.price / 100,
                'hours',
                lambda x: x.total / 100,
                lambda x: x.coupon.amount / 100 if x.coupon is not None else 0,
                'completed_hours',
                lambda x: x.completed_amount() / 100,
                'remaining_hours',
                lambda x: x.remaining_amount() / 100,
                lambda x: x.refund_info().refund_hours if x.refund_info() is not None else 0,
                lambda x: x.refund_info().refund_amount / 100 if x.refund_info() is not None else 0,
                'real_completed_hours',
                lambda x: x.real_order_amount() / 100,
            )
            return excel.excel_response(query_set, columns, headers, '订单记录.xls')
        return render(request, self.template_name, context)


class OrderRefundView(BaseStaffView):
    template_name = 'staff/order/refund.html'

    def get_context_data(self, **kwargs):

        # 把查询参数数据放到kwargs['query_data'], 以便template回显
        kwargs['query_data'] = self.request.GET.dict()
        refund_date_from = self.request.GET.get('refund_date_from')
        refund_date_to = self.request.GET.get('refund_date_to')
        name = self.request.GET.get('name')
        phone = self.request.GET.get('phone')
        order_id = self.request.GET.get('order_id')
        subject = self.request.GET.get('subject')
        status = self.request.GET.get('status')
        page = self.request.GET.get('page')
        export = self.request.GET.get('export')

        query_set = models.Order.objects.filter()
        # 退费申请区间
        if refund_date_from:
            try:
                date_from = parse_date(refund_date_from)
                query_set = query_set.filter(refund_at__gte=date_from)
            except Exception as e:
                pass
        if refund_date_to:
            try:
                date_to = parse_date_next(refund_date_to)
                query_set = query_set.filter(refund_at__lt=date_to)
            except Exception as e:
                pass
        # 家长姓名 or 学生姓名 or 老师姓名, 模糊匹配
        if name:
            query_set = query_set.filter(
                Q(parent__user__username__icontains=name) |
                Q(parent__student_name__icontains=name) |
                Q(teacher__name__icontains=name)
            )
        # 家长手机 or 老师手机, 模糊匹配
        if phone:
            query_set = query_set.filter(
                Q(parent__user__profile__phone__contains=phone) |
                Q(teacher__user__profile__phone__contains=phone)
            )
        # 后台系统订单号, 模糊匹配
        if order_id:
            query_set = query_set.filter(order_id__icontains=order_id)
        # 科目
        if subject:
            query_set = query_set.filter(subject=subject)
        # 订单状态
        if status:
            query_set = query_set.filter(refund_status=status)
        else:
            query_set = query_set.filter(refund_status__isnull=False)

        # 可用筛选条件数据集
        # 去除 审核被驳回 的状态, 前端不需要显示
        all_status = models.Order.REFUND_STATUS_CHOICES
        remove_status = [models.Order.REFUND_REJECTED]
        kwargs['status'] = []
        for key, text in all_status:
            if key in remove_status:
                continue
            else:
                kwargs['status'].append((key, text))
        kwargs['subjects'] = models.Subject.objects.all()
        # 查询结果数据集, 默认按下单时间排序
        query_set = query_set.order_by('-refund_at')
        if export is not None:
            # 导出操作, 直接给 query_set
            return query_set
        # 非导出操作, 继续分页显示
        query_set, pager = paginate(query_set, page)
        kwargs['pager'] = pager
        kwargs['orders'] = query_set
        return super(OrderRefundView, self).get_context_data(**kwargs)

    def get(self, request):
        context = self.get_context_data()
        export = self.request.GET.get('export')
        if export:
            query_set = context
            headers = (
                '申请时间',
                '订单号',
                '家长手机号',
                '学生姓名',
                '老师姓名',
                '老师手机号',
                '报课年级',
                '报课科目',
                '上课地址',
                '购买小时',
                '小时单价',
                '剩余小时',
                '退费小时',
                '奖学金',
                '退费金额',
                '状态',
                '退费原因',
                '是否排课',
            )
            columns = (
                lambda x: timezone.make_naive(x.refund_info().created_at),
                'order_id',
                'parent.user.profile.phone',
                'parent.student_name',
                'teacher.name',
                'teacher.user.profile.phone',
                'grade',
                'subject',
                'school',
                'hours',
                lambda x: x.price/100,
                'refund_info.remaining_hours',
                'refund_info.refund_hours',
                lambda x: x.coupon.amount/100 if x.coupon is not None else 0,
                lambda x: x.refund_info().refund_amount/100,
                'get_refund_status_display',
                'refund_info.reason',
                lambda x: '是' if x.is_timeslot_allocated() else '否',
            )
            return excel.excel_response(query_set, columns, headers, '退费审核记录.xls')
        return render(request, self.template_name, context)


class OrderRefundActionView(BaseStaffActionView):
    def get(self, request):
        action = self.request.GET.get('action')
        if action == 'preview-refund-info':
            return self.preview_refund_info(request)
        if action == 'get-refund-record':
            return self.get_refund_record(request)
        return HttpResponse("Not supported action.", status=404)

    def post(self, request):
        action = self.request.POST.get('action')
        if action == 'request-refund':
            return self.request_refund(request)
        if action == 'refund-approve':
            return self.refund_approve(request)
        if action == 'refund-reject':
            return self.refund_reject(request)
        return HttpResponse("Not supported action.", status=404)

    def preview_refund_info(self, request):
        order_id = request.GET.get('order_id')
        order = models.Order.objects.get(id=order_id)
        # 只要是已支付的, 都可以预览退费信息, 包括 审核中 和 已驳回
        if order.status != order.PAID:
            return JsonResponse(
                {'ok': False, 'msg': '订单还未支付', 'code': 'order_01'})
        # 目前退费只支持双师直播
        if order.live_class is None:
            return JsonResponse(
                {'ok': False, 'msg': '只有双师直播可以退款', 'code': 'order_02'})
        # 根据当前时间点,计算退费信息
        live_course = order.live_class.live_course
        discount_amount = order.coupon.amount if order.coupon is not None else 0
        return JsonResponse({
            'ok': True,
            'orderLessons': order.total_lessons(),              # 订单课次
            'finishLessons': live_course.finish_lessons,        # 完成课次
            'completedHours': order.completed_hours(),          # 完成小时
            'remainingLessons': live_course.remaining_lessons,  # 剩余课次
            'remainingHours': order.remaining_hours(),          # 剩余小时
            'onTheLessonTime': live_course.on_the_lesson_time,  # 开课时间(无课为0，单位是分钟)
            'discountAmount': discount_amount,                  # 扣除优惠金额(单位分)
            'pricePerHour': order.price,                        # 小时单价(单位分)
            'reason': order.refund_info().reason if order.refund_info() is not None else ''  # 退费原因
        })

    def get_refund_record(self, request):
        order_id = request.GET.get('order_id')
        order = models.Order.objects.get(id=order_id)
        if order.refund_info() is not None:
            record = order.refund_info()
            # 将之前申请退费时记录下来的退费信息返回给前端
            return JsonResponse({
                'ok': True,
                'orderLessonsRecord': record.total_lessons,             # 订单课次
                'finishLessonsRecord': record.finish_lessons,           # 完成课次
                'completedHoursRecord': record.completed_hours,         # 完成小时
                'remainingLessonsRecord': record.remaining_lessons,     # 剩余课次
                'remainingHoursRecord': record.remaining_hours,         # 剩余小时
                'onTheLessonTimeRecord': record.on_the_lesson_time,     # 开课时间(无课为0，单位是分钟)
                'discountAmountRecord': record.discount_amount,         # 扣除优惠金额(单位分)
                'pricePerHourRecord': record.hour_price,                # 小时单价(单位分)
                'refundLessonsRecord': record.refund_lessons,           # 退费课次
                'refundHoursRecord': record.refund_hours,               # 退费小时
                'refundAmountRecord': record.refund_amount,             # 退费金额
                'reasonRecord': record.reason                           # 退费原因
            })
        return JsonResponse({'ok': False, 'msg': '订单无申请退费记录', 'code': 'order_02'})

    def request_refund(self, request):
        order_id = request.POST.get('order_id')
        order = models.Order.objects.get(id=order_id)
        reason = request.POST.get('reason')
        lessons_count = request.POST.get('lessons_count', 0)
        try:
            models.Order.objects.refund(order, reason, self.request.user, lessons_count)
            # 短信通知家长
            parent = order.parent
            student_name = parent.student_name or parent.user.profile.mask_phone()
            _try_send_sms(parent.user.profile.phone, smsUtil.TPL_STU_REFUND_REQUEST, {'studentname': student_name}, 3)
            # 短信通知老师
            teacher = order.teacher
            _try_send_sms(teacher.user.profile.phone, smsUtil.TPL_REFUND_NOTICE, {'username': teacher.name}, 2)

            return JsonResponse({'ok': True})
        except OrderStatusIncorrect as e:
            return JsonResponse({'ok': False, 'msg': '%s' % e})
        except RefundError as e:
            return JsonResponse({'ok': False, 'msg': '%s' % e})

    def refund_approve(self, request):
        order_id = request.POST.get('order_id')
        order = models.Order.objects.get(id=order_id)
        if order.last_refund_record() is not None:
            ok = order.last_refund_record().approve_refund()
            if ok:
                order.last_refund_record().last_updated_by = self.request.user
                order.save()
                # 短信通知家长
                parent = order.parent
                student_name = parent.student_name or parent.user.profile.mask_phone()
                amount_str = "%.2f"%(order.last_refund_record().refund_amount/100)
                _try_send_sms(parent.user.profile.phone, smsUtil.TPL_STU_REFUND_APPROVE, {'studentname': student_name, 'amount': amount_str}, 3)
                # JPush 通知
                extras = {
                    "type": Remind.ORDER_REFUNDED,  # 退费成功
                    "code": order.id
                }
                send_push.delay(
                    "您有一笔退费已完成，点击查看",
                    title=Remind.title(Remind.ORDER_REFUNDED),
                    user_ids=[parent.user_id],
                    extras=extras
                )
                return JsonResponse({'ok': True})
        return JsonResponse({'ok': False, 'msg': '退费审核失败, 请检查订单状态', 'code': 'order_06'})

    def refund_reject(self, request):
        order_id = request.POST.get('order_id')
        order = models.Order.objects.get(id=order_id)
        if order.last_refund_record() is not None:
            ok = order.last_refund_record().reject_refund()
            if ok:
                order.last_refund_record().last_updated_by = self.request.user
                order.save()
                return JsonResponse({'ok': True})
        return JsonResponse({'ok': False, 'msg': '退费驳回失败, 请检查订单状态', 'code': 'order_07'})


class SchoolTimeslotView(BaseStaffView):
    template_name = 'staff/school/timeslot.html'

    def get_context_data(self, **kwargs):
        context = super(SchoolTimeslotView, self).get_context_data(**kwargs)
        schoolId = self.request.GET.get('schoolId')
        searchTime = self.request.GET.get('searchDate')
        searchName = self.request.GET.get('name')
        phone = self.request.GET.get('phone')

        schools = models.School.objects.all()
        if self.school_master is not None:
            schools = schools.filter(schoolmaster=self.school_master)

        timeslots = None
        stTime = None
        edTime = None
        if not searchTime:
            searchTime = datetime.datetime.now()
            stTime = datetime.datetime(searchTime.year, searchTime.month, searchTime.day)
        else:
            stTime = datetime.datetime.strptime(searchTime, '%Y-%m-%d')
        stTime = timezone.make_aware(stTime)

        edTime = stTime + datetime.timedelta(days=1)

        timeslots = models.TimeSlot.objects.filter(start__gte=stTime, end__lt=edTime, deleted=False)
        if searchName:
            timeslots = timeslots.filter(Q(order__parent__user__username__icontains=searchName)|Q(order__teacher__user__username__icontains=searchName))
        if phone:
            timeslots = timeslots.filter(Q(order__parent__user__profile__phone__icontains=phone)|Q(order__teacher__user__profile__phone__icontains=phone))
        if not schoolId and len(schools) > 0:
            schoolId = schools[0].id

        timeslots = timeslots.filter(order__school__id=schoolId).order_by('start')

        itemsLen = len(timeslots)
        ind = 0
        next_eq_ind = 0
        while ind < itemsLen:
            itm = timeslots[ind]
            if itm.complaint:
                itm.complaint.content = JSONRenderer().render(itm.complaint.content)
            eq_count = 0
            nind = ind +1
            if nind > next_eq_ind:
                while nind < itemsLen:
                    nitm = timeslots[nind]
                    if(itm.start == nitm.start) and (itm.end == nitm.end):
                        eq_count += 1
                        next_eq_ind = nind
                        nind += 1
                    else:
                        nind += 1
                        break
                itm.eq_count = eq_count

            if ind > 0:
                oitm = timeslots[ind - 1]
                if(itm.start == oitm.start) and (itm.end == oitm.end):
                    itm.eq_count = -1
            ind += 1

        context['schools'] = schools
        context['timeslots'] = timeslots
        context['searchTime'] = stTime
        context['schoolId'] = schoolId
        context['name'] = searchName
        context['phone'] = phone
        context['weekday'] = ("周日","周一","周二","周三","周四","周五","周六")[int(stTime.strftime("%w"))]
        return context

    def get(self, request):
        context = self.get_context_data()
        return render(request, self.template_name, context)

    def post(self, request):
        if request.POST.get('action') == 'saveComplaint':
            timeslotId = request.POST.get('timeslotId')
            complaintId = request.POST.get('complaintId')
            complaintContent = request.POST.get('complaintContent')

            if not timeslotId:
                return JsonResponse({'ok': False, 'msg': '必须提供课程编号', 'code': -1})

            if not complaintId:
                cmp = models.TimeSlotComplaint(content=complaintContent)
                cmp.save()
                models.TimeSlot.objects.filter(id=timeslotId).update(complaint_id = cmp.id)
            else:
                models.TimeSlotComplaint.objects.filter(id=complaintId).update(content=complaintContent)
                models.TimeSlot.objects.filter(id=timeslotId).update(complaint_id = complaintId)

            return JsonResponse({'ok': True, 'msg': '', 'code': 0})

        if request.POST.get('action') == 'saveAttendace':
            timeslotId = request.POST.get('timeslotId')
            attendanceId = request.POST.get('attendanceId')
            attendanceValue = request.POST.get('attendanceValue')

            if not timeslotId:
                return JsonResponse({'ok': False, 'msg': '必须提供课程编号', 'code': -1})
            if not attendanceValue:
                return JsonResponse({'ok': False, 'msg': '必须提供考勤状态', 'code': -1})

            if not attendanceId:
                at = models.TimeSlotAttendance(record_type=attendanceValue)
                at.save()
                models.TimeSlot.objects.filter(id=timeslotId).update(attendance_id = at.id)
            else:
                models.TimeSlotAttendance.objects.filter(id=attendanceId).update(record_type=attendanceValue)
                models.TimeSlot.objects.filter(id=timeslotId).update(attendance_id = attendanceId)

            return JsonResponse({'ok': True, 'msg': '', 'code': 0})

        return JsonResponse({'ok': False, 'msg': '系统错误', 'code': -1})

class CouponConfigView(BaseStaffView):
    template_name = 'staff/coupon/config.html'

    def get_context_data(self, **kwargs):
        context = super(CouponConfigView, self).get_context_data(**kwargs)

        return context

    def get(self, request):
        context = self.get_context_data()
        coupon_rules = models.CouponRule.objects.order_by('id')
        coupon_generators = models.CouponGenerator.objects.order_by('-id')
        context['couponRule'] = list(coupon_rules)
        context['couponGenerator'] = list(coupon_generators) and coupon_generators[0]

        return render(request, self.template_name, context)

    def post(self, request):
        context = self.get_context_data()

        couponType = self.request.POST.get('couponType')
        used = self.request.POST.get('opened')
        if used == '1':
            used = True
        else:
            used = False
        couponName = self.request.POST.get('couponName')
        amount = self.request.POST.get('amount', 0)
        mini_course_count = self.request.POST.get('mini_course_count', 0)
        mini_total_price = self.request.POST.get('mini_total_price', 0)
        parent_phone = self.request.POST.get('parent_phone')
        expiredAt = self.request.POST.get('expiredAt')
        validatedStart = self.request.POST.get('validatedStart')
        coupon_rules = self.request.POST.get('coupon_rules')
        coupon_rules_list = None
        if coupon_rules:
            coupon_rules_list = json.loads(coupon_rules)
            models.CouponRule.objects.all().delete()
            for item in coupon_rules_list:
                models.CouponRule(content=item).save()

        if couponType == 'new':
            coupon_generators = models.CouponGenerator.objects.order_by('-id')
            gen = None
            if coupon_generators:
                gen = coupon_generators[0]
            else:
                gen = models.CouponGenerator()
            gen.activated = used
            if validatedStart:
                gen.validated_start = datetime.datetime.strptime(validatedStart, '%Y-%m-%d')
            if expiredAt:
                gen.expired_at = datetime.datetime.strptime(expiredAt, '%Y-%m-%d')
                gen.expired_at = gen.expired_at.replace(hour=23, minute=59, second=59)
            try:
                gen.amount = int(amount)*100
            except Exception as e:
                gen.amount = 0
            try:
                gen.mini_course_count = int(mini_course_count)
            except Exception as e:
                gen.mini_course_count = 0
            try:
                gen.mini_total_price = int(mini_total_price)*100
            except Exception as e:
                gen.mini_total_price = 0

            gen.save()

        elif couponType == 'give':
            query_set = models.Parent.objects.filter()
            query_set = query_set.filter(user__profile__phone = parent_phone)
            if query_set.count() == 0:
                return JsonResponse({'ok': False, 'msg': '家长不存在', 'code': -1})

            if validatedStart:
                validated_start = datetime.datetime.strptime(validatedStart, '%Y-%m-%d')
            else:
                validated_start = timezone.now()
            if expiredAt:
                expired_at = datetime.datetime.strptime(expiredAt, '%Y-%m-%d')
                expired_at = expired_at.replace(hour=23, minute=59, second=59)
            else:
                expired_at = timezone.now()
            try:
                amount = int(amount)
            except Exception as e:
                amount = 0
            try:
                mini_course_count = int(mini_course_count)
            except Exception as e:
                mini_course_count = 0
            try:
                mini_total_price = int(mini_total_price)*100
            except Exception as e:
                mini_total_price = 0
            cp = models.Coupon(
                parent=query_set[0],
                name=couponName,
                amount=amount*100,
                mini_course_count=mini_course_count,
                mini_total_price=mini_total_price,
                expired_at=expired_at,
                used=False
            )
            cp.save()

        return JsonResponse({'ok': True, 'msg': 'OK', 'code': 0})


class EvaluationView(BaseStaffView):
    template_name = 'staff/evaluation/evaluations.html'

    def get_context_data(self, **kwargs):

        # 把查询参数数据放到kwargs['query_data'], 以便template回显
        kwargs['query_data'] = self.request.GET.dict()
        name = self.request.GET.get('name')
        phone = self.request.GET.get('phone')
        status = self.request.GET.get('status')
        order_date = self.request.GET.get('order_date')
        evaluation_date = self.request.GET.get('evaluation_date')
        page = self.request.GET.get('page')

        query_set = models.Evaluation.objects.filter()
        # 家长姓名 or 学生姓名 or 老师姓名, 模糊匹配
        if name:
            query_set = query_set.filter(
                Q(order__parent__user__username__icontains=name) |
                Q(order__parent__student_name__icontains=name) |
                Q(order__teacher__name__icontains=name)
            )
        # 家长手机 or 老师手机, 模糊匹配
        if phone:
            query_set = query_set.filter(
                Q(order__parent__user__profile__phone__contains=phone) |
                Q(order__teacher__user__profile__phone__contains=phone)
            )
        # 测评状态
        if status:
            # 此处 status 是前端传过来的值, 需要进一步判断具体状态
            if status == models.Order.REFUND:
                # 已退费
                query_set = query_set.filter(order__status=models.Order.REFUND)
            else:
                query_set = query_set.filter(status=status)

        # 下单日期
        if order_date:
            try:
                date = datetime.datetime.strptime(order_date, '%Y-%m-%d')
                query_set = query_set.filter(order__created_at__date=date.date())
            except Exception as e:
                pass
        # 测评时间
        if evaluation_date:
            try:
                date = datetime.datetime.strptime(evaluation_date, '%Y-%m-%d')
                query_set = query_set.filter(start__date=date.date())
            except Exception as e:
                pass

        # 可用筛选条件数据集
        all_status = models.Evaluation.STATUS_CHOICES
        kwargs['status'] = []
        for key, text in all_status:
            kwargs['status'].append((key, text))
        kwargs['status'].append((models.Order.REFUND, '已退费'))
        # 查询结果数据集, 默认按下单时间排序
        query_set = query_set.order_by('-order__created_at')
        # paginate
        query_set, pager = paginate(query_set, page)
        kwargs['evaluations'] = query_set
        kwargs['pager'] = pager
        kwargs['daily_timeslots'] = models.WeeklyTimeSlot.DAILY_TIME_SLOTS  # TODO: diff according to region
        return super(EvaluationView, self).get_context_data(**kwargs)


class EvaluationActionView(BaseStaffActionView):
    def post(self, request):
        action = self.request.POST.get('action')
        if action == 'schedule-evaluation':
            return self.schedule_evaluation(request)
        if action == 'complete-evaluation':
            return self.complete_evaluation(request)
        return HttpResponse("Not supported action.", status=404)

    def schedule_evaluation(self, request):
        eid = request.POST.get('eid')
        schedule_date = request.POST.get('schedule_date')
        schedule_time_index = request.POST.get('schedule_time')
        # TODO: models.WeeklyTimeSlot.DAILY_TIME_SLOTS diff according to region
        for index, slot in enumerate(models.WeeklyTimeSlot.DAILY_TIME_SLOTS, start=0):
            if index == int(schedule_time_index):
                date = datetime.datetime.strptime(schedule_date, '%Y-%m-%d')
                start = timezone.make_aware(datetime.datetime.combine(date, slot['start']))
                end = timezone.make_aware(datetime.datetime.combine(date, slot['end']))
                evaluation = models.Evaluation.objects.get(id=eid)
                if evaluation.schedule(start, end):
                    order = evaluation.order
                    subject = "%s%s" % (evaluation.order.grade.name, evaluation.order.subject.name)
                    sched_time = "%s-%s" % (timezone.localtime(evaluation.start).strftime('%m月%d日%H:%M'),
                                          timezone.localtime(evaluation.end).strftime('%H:%M'))
                    # JPush 通知
                    extras = {
                        "type": Remind.EVALUATION_SCHEDULED,  # 测评建档
                        "code": None
                    }
                    msg = "您已预约%s的%s课程测评建档服务" % (sched_time, subject)
                    send_push.delay(
                        msg,
                        title=Remind.title(Remind.EVALUATION_SCHEDULED),
                        user_ids=[order.parent.user_id],
                        extras=extras
                    )
                    # 短信通知家长和老师
                    parent_phone = order.parent.user.profile.phone
                    _try_send_sms(parent_phone, smsUtil.TPL_STU_EVALUATE, {'subject': subject, 'datatime': sched_time}, 3)
                    teacher_phone = order.teacher.user.profile.phone
                    _try_send_sms(teacher_phone, smsUtil.TPL_TEACHER_EVALUATE, {'subject': subject, 'datetime': sched_time}, 2)
                    return JsonResponse({'ok': True})
                else:
                    return JsonResponse({'ok': False, 'msg': '测评已完成, 无法再次安排时间', 'code': 'evaluation_status'})
        return JsonResponse({'ok': False, 'msg': '安排测评时间失败, 请稍后重试或联系管理员', 'code': 'schedule_evaluation'})

    def complete_evaluation(self, request):
        eid = request.POST.get('eid')
        evaluation = models.Evaluation.objects.get(id=eid)
        if evaluation.complete():
            return JsonResponse({'ok': True})
        else:
            return JsonResponse({'ok': False, 'msg': '未安排测评时间, 无法设置完成状态', 'code': 'evaluation_status'})
            # return JsonResponse({'ok': False, 'msg': '设置测评完成失败, 请稍后重试或联系管理员', 'code': 'complete_evaluation'})


class LevelPriceConfigView(BaseStaffView):
    """
    级别的价格设置界面
    """
    template_name = 'staff/level/price_cfg.html'

    def build_context(self, context, prices, levels, grades):
        if not prices or not levels:
            context['level_list'] = []
            return
        level_list = list(levels)
        for level in level_list:
            level.grades = []
            for grade in grades:
                grade_obj = {'id': grade.id, 'name': grade.name, 'price': None}
                level.grades.append(grade_obj)
                for price in prices:
                    if price.level_id == level.id and price.ability.grade_id == grade.id:
                        grade_obj['price'] = price.price
                        break

            level.min_price = min(level.grades, key= lambda x: x['price'] or 100000000)['price']
            level.max_price = max(level.grades, key= lambda x: x['price'] or -1)['price']
        context['level_list'] = level_list

    def get_context_data(self, **kwargs):
        # 把查询参数数据放到kwargs['query_data'], 以便template回显
        kwargs['query_data'] = self.request.GET.dict()
        region = self.request.GET.get('region')
        subject = self.request.GET.get('subject')
        prices = None
        if region and region.isdigit():
            prices = models.Price.objects.filter(region_id=region)
        if subject and subject.isdigit():
            prices = prices and prices.filter(ability__subject_id=subject)
        all_levels= models.Level.objects.all()
        all_grades = models.Grade.objects.filter(leaf=True)
        all_subject = models.Subject.objects.all()
        self.build_context(kwargs, prices, all_levels, all_grades)
        kwargs['grade_list'] = all_grades
        kwargs['subject_list'] = all_subject
        kwargs['region_list'] = models.Region.objects.filter(Q(opened=True)|Q(name='其他'))
        return super(LevelPriceConfigView, self).get_context_data(**kwargs)

    def post(self, request):
        region_id = request.POST.get('region')
        level_id = request.POST.get('level')
        grade_id = request.POST.get('grade')
        subject_id = request.POST.get('subject')
        price = request.POST.get('price')
        if not region_id or not level_id or not price:
            return HttpResponse(status=400)
        try:
            new_price = float(price)
        except Exception as e:
            new_price = -1
        if new_price < 0:
            return JsonResponse({'ok': False, 'msg': '价格范围错误', 'code': 1})
        region = get_object_or_404(models.Region, id=region_id)
        grade = grade_id and get_object_or_404(models.Grade, id=grade_id) or None
        subject = subject_id and get_object_or_404(models.Subject, id=subject_id) or None
        level = get_object_or_404(models.Level, id=level_id)
        query_set = models.Price.objects.filter(region=region, level=level)
        if grade:
            query_set = query_set.filter(ability__grade=grade)
        if subject:
            query_set = query_set.filter(ability__subject=subject)
        num = query_set.update(price=int(new_price * 100))
        logger.info("修改地区%s级别%s%s%s的课时价格为%s, 数据库影响%s条"%(
            region.name, level.name, grade and grade.name or '所有年级',
            subject and subject.name or '所有科目', new_price, num))
        return JsonResponse({'ok': True, 'msg': '保存成功', 'code': 0})


class LevelSalaryConfigView(BaseStaffView):
    """
    级别的薪资设置界面
    """
    template_name = 'staff/level/salary_cfg.html'

    def build_context(self, context, prices, levels):
        if not prices or not levels:
            context['level_list'] = []
            return
        level_list = list(levels)
        price_dict = {price.level_id: price for price in prices}
        for level in level_list:
            p = price_dict.get(level.id)
            level.commission_percentage = p and p.commission_percentage or 0
        context['level_list'] = level_list

    def get_context_data(self, **kwargs):
        # 把查询参数数据放到kwargs['query_data'], 以便template回显
        kwargs['query_data'] = self.request.GET.dict()
        region = self.request.GET.get('region')
        prices = []
        if region and region.isdigit():
            prices = models.Price.objects.filter(region_id=region)
        all_levels= models.Level.objects.all()
        self.build_context(kwargs, prices, all_levels)
        kwargs['region_list'] = models.Region.objects.filter(Q(opened=True)|Q(name='其他'))
        return super(LevelSalaryConfigView, self).get_context_data(**kwargs)

    def post(self, request):
        region_id = request.POST.get('region')
        level_id = request.POST.get('level')
        commission_percentage = request.POST.get('commission_percentage')
        if not region_id or not level_id or not commission_percentage:
            return HttpResponse(status=400)
        try:
            new_percent = int(commission_percentage)
        except Exception as e:
            new_percent = -1
        if not (0 <= new_percent <= 100):
            return JsonResponse({'ok': False, 'msg': '佣金比例范围错误', 'code': 1})
        region = get_object_or_404(models.Region, id=region_id)
        level = get_object_or_404(models.Level, id=level_id)
        num = models.Price.objects.filter(region=region, level=level).update(commission_percentage=new_percent)
        logger.info("修改地区%s级别%s的佣金比例为%s, 数据库影响%s条"%(region.name, level.name, new_percent, num))
        return JsonResponse({'ok': True, 'msg': '保存成功', 'code': 0})


class SchoolPriceConfigView(BaseStaffView):
    """
    校区的价格设置界面 (from 2016年9月21日, 区别LevelPriceConfigView, 那个View对应到地区, 这个对应到学校)
    """
    template_name = 'staff/school/price_cfg.html'

    def get_context_data(self, **kwargs):
        # 检查是否是校长
        school_master = self.school_master
        is_school_master = school_master is not None and school_master.school is not None
        kwargs['is_school_master'] = is_school_master
        if not is_school_master:
            return super(SchoolPriceConfigView, self).get_context_data(**kwargs)
        # 基础数据
        school_master.school.init_prices()  # init the prices if no prices
        all_levels= models.Level.objects.all()
        all_grades = models.Grade.objects.filter(leaf=True)
        kwargs['level_list'] = all_levels
        kwargs['grade_list'] = all_grades
        # 把查询参数数据放到kwargs['query_data'], 以便template回显
        kwargs['query_data'] = self.request.GET.dict()
        level_id = self.request.GET.get('level_id')
        if not level_id:
            level_id = "1" # 默认级别
        kwargs['query_data']['level_id'] = int(level_id)
        prices = models.PriceConfig.objects.filter(
            school=school_master.school, level_id=level_id, deleted=False)
        self.build_prices_table_data(kwargs, prices, all_grades)
        return super(SchoolPriceConfigView, self).get_context_data(**kwargs)

    def build_prices_table_data(self, context, prices, grades):
        if not prices or not grades:
            context['price_range_list'] = []
            return
        range_list = []
        range_heap = {}
        price_heap = {}
        for p_c in prices:
            range_key = '%s~%s' % (p_c.min_hours, p_c.max_hours)
            cur_range = range_heap.get(range_key)
            if not cur_range:
                cur_range = {'min_hours': p_c.min_hours, 'max_hours': p_c.max_hours, 'grade_price_map':{}}
                range_heap[range_key] = cur_range
                range_list.append(cur_range)
            price_heap[p_c.pk] = p_c.price
            cur_range['grade_price_map'][p_c.grade_id] = p_c.pk
        # 排序
        range_list.sort(key=lambda x: x['min_hours'])
        # 再次整理年级
        for range1 in range_list:
            grade_price_map = range1.pop('grade_price_map')
            grade_list = []
            for g in grades:
                pk = grade_price_map.get(g.id) # price_config item id
                cur_grade = {'id': g.id, 'name': g.name, 'pk': pk, 'price': pk and price_heap.get(pk)}
                grade_list.append(cur_grade)
            grade_list.sort(key=lambda x: x['id'])
            range1['grades'] = grade_list
        context['price_range_list'] = range_list

    def post(self, request):
        # 检查是否是校长
        school_master = self.school_master
        is_school_master = school_master is not None and school_master.school is not None
        if not is_school_master:
            return JsonResponse({'ok': False, 'msg': '您不是校长, 不需要操作', 'code': 1})
        # 获取参数
        pk = request.POST.get('pk')
        price = request.POST.get('price')
        try:
            new_price = float(price)
        except Exception as e:
            new_price = -1
        if new_price < 0:
            return JsonResponse({'ok': False, 'msg': '价格范围错误', 'code': 2})
        cur_price = models.PriceConfig.objects.get(pk=pk)
        # 判断是否是该学校数据
        if cur_price.school_id != school_master.school_id:
            return JsonResponse({'ok': False, 'msg': '您不是该学校校长, 没有权限操作此项数据', 'code': 3})
        cur_price.price = int(new_price * 100)
        cur_price.save()
        return JsonResponse({'ok': True, 'msg': '保存成功', 'code': 0})


class SchoolAccountInfoView(BaseStaffView):
    """
    学校账号信息编辑和显示页面
    """
    template_name = 'staff/school_account/info.html'

    def get(self, request, *args, **kwargs):
        if not request.GET.get('show') == 'true':
            # 检查是否已经配置过校区账号
            school_master = self.school_master
            school = school_master and school_master.school
            if school and hasattr(school, 'schoolaccount'):
                return redirect('staff:school_income_records')
        return super(SchoolAccountInfoView, self).get(request, *args, **kwargs)

    def get_context_data(self, **kwargs):
        # 检查是否是校长
        school_master = self.school_master
        is_school_master = school_master is not None and school_master.school is not None
        kwargs['is_school_master'] = is_school_master
        if not is_school_master:
            return super(SchoolAccountInfoView, self).get_context_data(**kwargs)
        # 获取学校属性, 该校区订单收入, 以及银行账号信息
        school = school_master.school
        kwargs['school_master'] = school_master
        kwargs['school'] = school

        school_account = None
        if hasattr(school, 'schoolaccount'):
            school_account = school.schoolaccount
        kwargs['school_account'] = school_account

        # 计算校区账户余额
        kwargs['account_balance'], _ = school.balance()

        return super(SchoolAccountInfoView, self).get_context_data(**kwargs)

    def post(self, request, *args, **kwargs):
        account_name = request.POST.get('account_name')
        account_number = request.POST.get('account_number')
        bank_name = request.POST.get('bank_name')
        bank_address = request.POST.get('bank_address')
        swift_code = request.POST.get('swift_code')

        # 检查是否是校长
        school_master = self.school_master
        is_school_master = school_master is not None and school_master.school is not None
        if not is_school_master:
            return JsonResponse({'ok': False, 'msg': '您不是校长, 不需要操作', 'code': 1})

        school_account = None
        if hasattr(school_master.school, 'schoolaccount'):
            # return JsonResponse({'ok': False, 'msg': '填写过后不允许修改, 若要修改请联系管理员', 'code': 2})
            school_account = school_master.school.schoolaccount
        else:
            school_account = models.SchoolAccount(school=school_master.school)

        school_account.account_name = account_name
        school_account.account_number = account_number
        school_account.bank_name = bank_name
        school_account.bank_address = bank_address
        school_account.swift_code = swift_code
        school_account.save()

        return JsonResponse({'ok': True, 'msg': '保存成功', 'code': 0})


class SchoolAccountInfoViewV2(BaseStaffView):
    """
    学校账号信息编辑和显示页面
    """
    template_name = 'staff/school_account/info.html'

    def get(self, request, *args, **kwargs):
        if not request.GET.get('show') == 'true':
            # 检查是否已经配置过校区账号
            school_master = self.school_master
            school = school_master and school_master.school
            if school and hasattr(school, 'schoolaccount'):
                return redirect('staff:school_income_records_v2')
        return super(SchoolAccountInfoViewV2, self).get(request, *args, **kwargs)

    def get_context_data(self, **kwargs):
        # 检查是否是校长
        school_master = self.school_master
        is_school_master = school_master is not None and school_master.school is not None
        kwargs['is_school_master'] = is_school_master
        if not is_school_master:
            return super(SchoolAccountInfoViewV2, self).get_context_data(**kwargs)
        # 获取学校属性, 该校区订单收入, 以及银行账号信息
        school = school_master.school
        kwargs['school_master'] = school_master
        kwargs['school'] = school

        school_account = None
        if hasattr(school, 'schoolaccount'):
            school_account = school.schoolaccount
        kwargs['school_account'] = school_account

        # 计算校区账户余额
        kwargs['account_balance'], _ = school.balance()

        return super(SchoolAccountInfoViewV2, self).get_context_data(**kwargs)

    def post(self, request, *args, **kwargs):
        account_name = request.POST.get('account_name')
        account_number = request.POST.get('account_number')
        bank_name = request.POST.get('bank_name')
        bank_address = request.POST.get('bank_address')
        swift_code = request.POST.get('swift_code')

        # 检查是否是校长
        school_master = self.school_master
        is_school_master = school_master is not None and school_master.school is not None
        if not is_school_master:
            return JsonResponse({'ok': False, 'msg': '您不是校长, 不需要操作', 'code': 1})

        school_account = None
        if hasattr(school_master.school, 'schoolaccount'):
            # return JsonResponse({'ok': False, 'msg': '填写过后不允许修改, 若要修改请联系管理员', 'code': 2})
            school_account = school_master.school.schoolaccount
        else:
            school_account = models.SchoolAccount(school=school_master.school)

        school_account.account_name = account_name
        school_account.account_number = account_number
        school_account.bank_name = bank_name
        school_account.bank_address = bank_address
        school_account.swift_code = swift_code
        school_account.save()

        return JsonResponse({'ok': True, 'msg': '保存成功', 'code': 0})


class SchoolIncomeRecordView(BaseStaffView):
    """
    学校账号信息编辑和显示页面
    """
    template_name = 'staff/school_account/records.html'

    def get_context_data(self, **kwargs):
        # 检查是否是校长
        school_master = self.school_master
        is_school_master = school_master is not None and school_master.school is not None
        kwargs['is_school_master'] = is_school_master
        if not is_school_master:
            return super(SchoolIncomeRecordView, self).get_context_data(**kwargs)
        # 获取学校属性, 该校区订单收入, 以及银行账号信息
        school = school_master.school
        kwargs['school_master'] = school_master
        kwargs['school'] = school

        school_account = None
        if hasattr(school, 'schoolaccount'):
            school_account = school.schoolaccount
        kwargs['school_account'] = school_account

        # 计算校区账户余额
        kwargs['account_balance'], balance_detail = school.balance()
        kwargs['balance_one_to_one'] = balance_detail.get('one_to_one')
        kwargs['balance_live_course'] = balance_detail.get('live_course')

        if school_account:
            # paginate
            page = self.request.GET.get('page')
            records = models.SchoolIncomeRecord.objects.filter(
                school_account=school_account,
                amount__gt=0,
            )
            records = records.order_by('-id')
            records, pager = paginate(records, page)
            kwargs['records'] = records
            kwargs['pager'] = pager

        return super(SchoolIncomeRecordView, self).get_context_data(**kwargs)


class SchoolIncomeRecordViewV2(BaseStaffView):
    """
    学校账号信息编辑和显示页面
    """
    template_name = 'staff/school_account/records_v2.html'

    def get_context_data(self, **kwargs):
        # 检查是否是校长
        school_master = self.school_master
        is_school_master = school_master is not None and school_master.school is not None
        kwargs['is_school_master'] = is_school_master
        if not is_school_master:
            return super(SchoolIncomeRecordViewV2, self).get_context_data(**kwargs)
        # 获取学校属性, 该校区订单收入, 以及银行账号信息
        school = school_master.school
        kwargs['school_master'] = school_master
        kwargs['school'] = school

        school_account = None
        if hasattr(school, 'schoolaccount'):
            school_account = school.schoolaccount
        kwargs['school_account'] = school_account

        # 计算校区账户余额
        kwargs['account_balance'], balance_detail = school.balance()
        kwargs['balance_one_to_one'] = balance_detail.get('one_to_one')
        kwargs['balance_live_course'] = balance_detail.get('live_course')

        if school_account:
            # paginate
            page = self.request.GET.get('page')
            records = models.SchoolIncomeRecord.objects.filter(
                school_account=school_account,
                amount__gt=0,
            )
            records = records.order_by('-id')
            records, pager = paginate(records, page)
            kwargs['records'] = records
            kwargs['pager'] = pager

        return super(SchoolIncomeRecordViewV2, self).get_context_data(**kwargs)


class SchoolIncomeAuditView(BaseStaffView):
    """
    学校账号信息编辑和显示页面
    """
    template_name = 'staff/school_account/income_audit.html'

    def get_context_data(self, **kwargs):  # paginate
        kwargs['query_data'] = self.request.GET.dict()
        page = self.request.GET.get('page')
        school = self.request.GET.get('school')
        records = models.SchoolIncomeRecord.objects.filter(amount__gt=0)
        if school and school.isdigit():
            records = records.filter(school_account__school_id=school)
        records = records.order_by('-id')
        records, pager = paginate(records, page)
        kwargs['records'] = records
        kwargs['pager'] = pager
        kwargs['schools'] = models.School.objects.filter(opened=True)
        return super(SchoolIncomeAuditView, self).get_context_data(**kwargs)

    def post(self, request, *args, **kwargs):
        action = request.POST.get('action')
        record_id = request.POST.get('rid')
        record = get_object_or_404(models.SchoolIncomeRecord, pk=record_id)
        if action == 'mark_yes':
            record.status = models.SchoolIncomeRecord.APPROVED
        elif action == 'mark_no':
            record.status = models.SchoolIncomeRecord.PENDING
        record.save()
        return JsonResponse({'ok': True, 'msg': '保存成功', 'code': 0})


class SchoolIncomeAuditViewV2(BaseStaffView):
    """
    学校账号信息编辑和显示页面
    """
    template_name = 'staff/school_account/income_audit_v2.html'

    def get_context_data(self, **kwargs):  # paginate
        kwargs['query_data'] = self.request.GET.dict()
        page = self.request.GET.get('page')
        school = self.request.GET.get('school')
        records = models.SchoolIncomeRecord.objects.filter(amount__gt=0)
        if school and school.isdigit():
            records = records.filter(school_account__school_id=school)
        records = records.order_by('-id')
        records, pager = paginate(records, page)
        kwargs['records'] = records
        kwargs['pager'] = pager
        kwargs['schools'] = models.School.objects.filter(opened=True)
        return super(SchoolIncomeAuditViewV2, self).get_context_data(**kwargs)

    def post(self, request, *args, **kwargs):
        action = request.POST.get('action')
        record_id = request.POST.get('rid')
        record = get_object_or_404(models.SchoolIncomeRecord, pk=record_id)
        if action == 'mark_yes':
            record.status = models.SchoolIncomeRecord.APPROVED
        elif action == 'mark_no':
            record.status = models.SchoolIncomeRecord.PENDING
        record.save()
        return JsonResponse({'ok': True, 'msg': '保存成功', 'code': 0})


class RegionView(BaseStaffView):
    """
    地区view: 地区属性编辑, 城市开通.etc
    """

    def get(self, request, rid, *args, **kwargs):
        region = get_object_or_404(models.Region, pk=rid)
        action = request.GET.get('action')
        if action == 'open':
            return self._open_city(region)

        html_buf = []
        html_buf.append(region.name)
        for wts in region.weekly_time_slots.all():
            html_buf.append(str(wts))
        return HttpResponse('<br>'.join(html_buf))

    def _open_city(self, region):
        if region.weekly_time_slots.count() == 0:
            for weekday in range(1, 8):
                for start in ((8, 0), (10, 30), (14, 0), (16, 30), (19, 0)):
                    end = (start[0] + 2, start[1])
                    weekly_time_slot = models.WeeklyTimeSlot(weekday=weekday, start=datetime.time(*start),
                            end=datetime.time(*end))
                    weekly_time_slot.save()
                    region.weekly_time_slots.add(weekly_time_slot)
        region.opened = True
        region.save()
        return HttpResponse('开通"%s"成功' % region.name)


class LiveCourseView(BaseStaffView):
    '''
    双师直播课程创建页面
    '''
    template_name = 'staff/course/live_course/show.html'

    def get_context_data(self, **kwargs):
        course_id = kwargs.get('cid')
        lc = None
        if course_id:
            lc = get_object_or_404(models.LiveCourse, pk=course_id)
            kwargs['dtlc'] = lc
        is_show = lc is not None
        kwargs['is_show'] = is_show
        kwargs['subjects'] = models.Subject.objects.all()
        kwargs['lecturers'] = models.Lecturer.objects.filter(deleted=False)
        kwargs['daily_time_slots'] = models.LiveCourseWeeklyTimeSlot.DAILY_TIME_SLOTS()
        # 校区教室, 各校区助教列表
        class_rooms = models.ClassRoom.objects.all()
        for class_room in class_rooms:
            class_room.assistants = models.Teacher.objects.filter(is_assistant=True, schools__in=[class_room.school])
        if is_show:
            live_classes = models.LiveClass.objects.filter(live_course=lc)
            room_assistant_dict = {c.class_room_id: c.assistant_id for c in live_classes}
            for class_room in class_rooms:
                class_room.assistant_id = room_assistant_dict.get(class_room.id)
            lc_timeslots = models.LiveCourseTimeSlot.objects.filter(live_course=lc)
            kwargs['timeslots'] = lc_timeslots
        kwargs['class_rooms'] = class_rooms
        kwargs['server_timestamp'] = int(timezone.now().timestamp())
        return super(LiveCourseView, self).get_context_data(**kwargs)

    def _check_post_params(self, params):
        if not params.get('course_no'):
            return "课程编号不能为空"
        if not params.get('name'):
            return "课程名称不能为空"
        if not params.get('course_times'):
            return "上课时间不能为空"
        if not params.get('period_desc'):
            return "时间段不能为空"
        if not params.get('grade_desc'):
            return "年级不能为空"
        if not params.get('subject'):
            return "科目不能为空"
        fee = params.get('fee')
        if not fee or float(fee) <= 0:
            return "费用不能为空, 并且必须是大于0的数"
        if not params.get('description'):
            return "课程介绍不能为空"
        if not params.get('lecturer'):
            return "讲师不能为空"
        if not params.get('class_rooms'):
            return "没有校区教室"
        chosen_as = []
        for room in params.get('class_rooms'):
            if not room.get('id'):
                return "校区教室参数错误"
            assistant = room.get('assistant')
            if not assistant:
                return "每个校区教室必须分配助教"
            if assistant in chosen_as:
                return "助教选择不能重复"
            chosen_as.append(assistant)
        return 'ok'

    def post(self, request):
        jsonstr = request.POST.get('data')
        if not jsonstr:
            return JsonResponse({'ok': False, 'msg': '参数格式错误', 'code': 1})
        try:
            params = json.loads(jsonstr)
        except Exception as ex:
            return JsonResponse({'ok': False, 'msg': '参数格式错误', 'code': 1})
        check_msg = self._check_post_params(params)
        if check_msg != 'ok':
            return JsonResponse({'ok': False, 'msg': check_msg, 'code': 2})
        course_no = params.get('course_no')
        name = params.get('name')
        course_times = params.get('course_times')
        period_desc = params.get('period_desc')
        grade_desc = params.get('grade_desc')
        subject = get_object_or_404(models.Subject, pk=params.get('subject'))
        fee = params.get('fee')
        description = params.get('description')
        lecturer = get_object_or_404(models.Lecturer, pk=params.get('lecturer'))
        class_rooms = params.get('class_rooms')
        live_class_list = []
        for room in class_rooms:
            class_room = get_object_or_404(models.ClassRoom, pk=room.get('id'))
            assistant = get_object_or_404(models.Teacher, pk=room.get('assistant'))
            live_class_list.append({
                'class_room': class_room,
                'assistant': assistant
            })

        try:
            with transaction.atomic():
                lc = models.LiveCourse(
                    course_no=course_no, name=name,
                    grade_desc=grade_desc, period_desc=period_desc,
                    subject=subject, lecturer=lecturer,
                    fee=int(float(fee) * 100), description=description,
                )
                lc.save()
                db_live_class_list = []
                for item in live_class_list:
                    lcl = models.LiveClass(
                        live_course=lc,
                        class_room=item['class_room'],
                        assistant=item['assistant'],
                    )
                    db_live_class_list.append(lcl)
                models.LiveClass.objects.bulk_create(db_live_class_list)
                db_course_time_list = []
                for time in course_times:
                    lctime = models.LiveCourseTimeSlot(
                        live_course=lc,
                        start=datetime.datetime.fromtimestamp(time.get('start')),
                        end=datetime.datetime.fromtimestamp(time.get('end')),
                    )
                    db_course_time_list.append(lctime)
                models.LiveCourseTimeSlot.objects.bulk_create(db_course_time_list)
        except IntegrityError as err:
            logger.error(err)
            return JsonResponse({'ok': False, 'msg': '操作失败, 请稍后重试或联系管理员', 'code': -1})

        return JsonResponse({'ok': True, 'msg': '', 'code': 0})


class CreateClassRoomView(BaseStaffView):
    template_name = 'staff/course/live_course/create_room.html'

    def get_context_data(self, **kwargs):
        kwargs['schools'] = models.School.objects.filter(opened=True)
        return super(CreateClassRoomView, self).get_context_data(**kwargs)

    def post(self, request):
        school_id = request.POST.get('school')
        school = get_object_or_404(models.School, id=school_id)
        name = request.POST.get('name')
        capacity = parseInt(request.POST.get('capacity'), 0)

        if not name:
            return JsonResponse({'ok': False, 'msg': '请输入教室名称'})
        if not capacity > 0:
            return JsonResponse({'ok': False, 'msg': '请输入有效学生数量'})

        if models.ClassRoom.objects.filter(school=school).exists():
            return JsonResponse({'ok': False, 'msg': '创建失败, 该校区已有教室'})

        new_room = models.ClassRoom(school=school,
                                    name=name,
                                    capacity=capacity)
        new_room.save()
        return JsonResponse({'ok': True, 'msg': '创建成功!'})


class LiveCourseListView(BaseStaffView):
    template_name = 'staff/course/live_course/live_course_list.html'

    def get_context_data(self, **kwargs):
        kwargs['query_data'] = self.request.GET.dict()
        status = self.request.GET.get('status')
        page = self.request.GET.get('page')
        live_courses = models.LiveCourse.objects.all()
        now = timezone.now()
        if status == 'to_start':
            live_courses = live_courses.annotate(
                start_time=Min("livecoursetimeslot__start"))
            live_courses = live_courses.filter(start_time__gt=now)
        elif status == 'under_way':
            live_courses = live_courses.annotate(
                start_time=Min("livecoursetimeslot__start"))
            live_courses = live_courses.annotate(
                end_time=Max("livecoursetimeslot__end"))
            live_courses = live_courses.filter(start_time__lte=now).filter(
                end_time__gte=now)
        elif status == 'end':
            live_courses = live_courses.annotate(
                end_time=Max("livecoursetimeslot__end"))
            live_courses = live_courses.filter(end_time__lt=now)
        live_courses = live_courses.order_by('-id')
        # paginate
        live_courses, pager = paginate(live_courses, page)
        kwargs['live_courses'] = live_courses
        kwargs['pager'] = pager
        return super(LiveCourseListView, self).get_context_data(**kwargs)


class StaffAuthView(BaseStaffView):
    def post(self, request):
        action = request.POST.get('action')
        if action == 'modpswd':
            return self._mod_password(request)
        return HttpResponse(status=403)

    def _mod_password(self, request):
        oldpswd = request.POST.get('oldpswd')
        newpswd = request.POST.get('newpswd')
        _re_pswd = re.compile(r'^[\W\w]{6,32}$')
        if not _re_pswd.match(newpswd):
            return JsonResponse({'ok': False, 'msg': '密码格式错误', 'code': 1})
        user = request.user
        if not user.check_password(oldpswd):
            return JsonResponse({'ok': False, 'msg': '原密码不正确', 'code': 2})
        user.set_password(newpswd)
        user.save()
        return JsonResponse({'ok': True, 'msg': '', 'code': 0})
