from django.conf import settings

import pingpp

pingpp.api_key = settings.PINGPP_API_KEY
# pingpp.private_key_path = settings.PINGPP_PRI_KEY_PATH
