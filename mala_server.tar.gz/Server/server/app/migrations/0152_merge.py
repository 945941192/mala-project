from django.db import migrations

class Migration(migrations.Migration):
    dependencies = [
        ('app', '0059_weeklytimeslot'),
        ('app', '0151_set_tenth_level_price'),
    ]

    operations = []