/**
 * Created by caoyawen on 16/2/25.
 */
$(
    function () {
        var confirm = $("#confirm");
        confirm.click(function(){
            window.location.href = "/teacher/wallet/";
        });
    }
);

