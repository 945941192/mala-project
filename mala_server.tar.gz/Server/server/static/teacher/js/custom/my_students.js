/**
 * Created by caoyawen on 16/2/1.
 */

$(function () {
  $('[data-toggle="tooltip"]').tooltip()
});
