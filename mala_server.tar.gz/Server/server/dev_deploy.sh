ssh -i dev_deploy.key -o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null ec2-user@dev.malalaoshi.com /home/ec2-user/bin/dev_deploy.sh
